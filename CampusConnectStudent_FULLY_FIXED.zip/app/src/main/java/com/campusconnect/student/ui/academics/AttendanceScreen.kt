package com.campusconnect.student.ui.academics

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.campusconnect.student.data.model.AttendanceRecord
import com.campusconnect.student.data.model.SubjectAttendance
import com.campusconnect.student.ui.common.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttendanceScreen(
    viewModel: AttendanceViewModel,
    onBackClick: () -> Unit
) {
    val uiState by viewModel.uiState
    val subjectAttendance by viewModel.subjectAttendance
    val history by viewModel.attendanceHistory

    Scaffold(
        topBar = {
            CampusAppBar(
                title = "Attendance",
                navigationIcon = Icons.Default.ArrowBack,
                onNavigationClick = onBackClick
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (uiState) {
                is AttendanceUiState.Loading -> LoadingState()
                else -> {
                    AttendanceContent(
                        subjectAttendance = subjectAttendance,
                        history = history
                    )
                }
            }
        }
    }
}

@Composable
fun AttendanceContent(
    subjectAttendance: List<SubjectAttendance>,
    history: List<AttendanceRecord>
) {
    val overallPercentage = if (subjectAttendance.isNotEmpty()) {
        subjectAttendance.map { it.percentage }.average().toFloat()
    } else 0f

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            OverallAttendanceCard(overallPercentage)
        }
        
        if (subjectAttendance.isNotEmpty()) {
            item {
                Text(
                    text = "Subject-wise Attendance",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            items(subjectAttendance) { item ->
                SubjectAttendanceItem(item)
            }
        }

        if (history.isNotEmpty()) {
            item {
                Text(
                    text = "Attendance History",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            items(history) { record ->
                HistoryItem(record)
            }
        }

        if (subjectAttendance.isEmpty() && history.isEmpty()) {
            item {
                EmptyState(message = "No attendance records found.")
            }
        }
    }
}

@Composable
fun OverallAttendanceCard(percentage: Float) {
    val isShortage = percentage < 75f
    val statusColor = if (isShortage) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary

    CampusCard {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "Overall Attendance", style = MaterialTheme.typography.labelLarge)
            Spacer(modifier = Modifier.height(8.dp))
            CircularProgressIndicator(
                progress = percentage / 100f,
                modifier = Modifier.size(100.dp),
                strokeWidth = 8.dp,
                color = statusColor,
                trackColor = statusColor.copy(alpha = 0.1f)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "${"%.1f".format(percentage)}%",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = statusColor
            )
            if (isShortage) {
                Text(
                    text = "Warning: Attendance below 75%",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun SubjectAttendanceItem(item: SubjectAttendance) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.subjectName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = item.subjectCode,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    text = "${item.percentage}%",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (item.percentage < 75f) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            LinearProgressIndicator(
                progress = item.percentage / 100f,
                modifier = Modifier.fillMaxWidth().height(8.dp),
                color = if (item.percentage < 75f) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Present: ${item.attendedClasses}", style = MaterialTheme.typography.bodySmall)
                Text(text = "Absent: ${item.absentClasses}", style = MaterialTheme.typography.bodySmall)
                Text(text = "Total: ${item.totalClasses}", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun HistoryItem(record: AttendanceRecord) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(text = record.subjectName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
            Text(text = record.date, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        val color = if (record.status.lowercase() == "present") Color(0xFF4CAF50) else MaterialTheme.colorScheme.error
        Surface(
            color = color.copy(alpha = 0.1f),
            shape = MaterialTheme.shapes.extraSmall
        ) {
            Text(
                text = record.status,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                style = MaterialTheme.typography.labelSmall,
                color = color,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
