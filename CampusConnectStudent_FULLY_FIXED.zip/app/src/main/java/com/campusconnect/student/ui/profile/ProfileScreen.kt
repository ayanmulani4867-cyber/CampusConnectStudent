package com.campusconnect.student.ui.profile

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.campusconnect.student.data.model.StudentUser
import com.campusconnect.student.ui.common.*
import com.campusconnect.student.utils.ImageUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    viewModel: ProfileViewModel,
    onLogout: () -> Unit
) {
    val profile by viewModel.studentProfile
    val uiState by viewModel.uiState
    val context = LocalContext.current

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            val part = ImageUtils.prepareImagePart(context, "photo", it)
            if (part != null) {
                viewModel.uploadPhoto(part)
            }
        }
    }

    Scaffold(
        topBar = {
            CampusAppBar(
                title = "My Profile",
                actions = {
                    IconButton(onClick = onLogout) {
                        Icon(imageVector = Icons.Default.Logout, contentDescription = "Logout")
                    }
                }
            )
        }
    ) { padding ->
        if (profile == null && uiState is ProfileUiState.Loading) {
            LoadingState(modifier = Modifier.padding(padding))
        } else if (profile == null) {
            ErrorState(
                message = "Failed to load profile",
                onRetry = { viewModel.refreshProfile() },
                modifier = Modifier.padding(padding)
            )
        } else {
            ProfileContent(
                profile = profile!!,
                onPhotoEdit = { photoPickerLauncher.launch("image/*") },
                modifier = Modifier.padding(padding)
            )
        }
    }
}

@Composable
fun ProfileContent(
    profile: StudentUser,
    onPhotoEdit: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        item {
            ProfileHeader(profile, onPhotoEdit)
        }
        item {
            ProfileSection(title = "Personal Information") {
                ProfileItem(label = "Email", value = profile.email ?: "-")
                ProfileItem(label = "Phone", value = profile.phone ?: "Not provided")
                ProfileItem(label = "Gender", value = profile.gender ?: "Not provided")
                ProfileItem(label = "Blood Group", value = profile.bloodGroup ?: "Not provided")
            }
        }
        item {
            ProfileSection(title = "Academic Details") {
                ProfileItem(label = "Department", value = profile.departmentName ?: "-")
                ProfileItem(label = "Course", value = profile.courseName ?: "-")
                ProfileItem(label = "Semester", value = profile.semesterNumber?.toString() ?: "-")
                ProfileItem(label = "Roll No", value = profile.rollNo ?: "-")
            }
        }
        item {
            ProfileSection(title = "Guardian Information") {
                ProfileItem(label = "Name", value = profile.guardianName ?: "-")
                ProfileItem(label = "Phone", value = profile.guardianPhone ?: "-")
            }
        }
    }
}

@Composable
fun ProfileHeader(profile: StudentUser, onPhotoEdit: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box {
            Surface(
                modifier = Modifier.size(100.dp),
                shape = MaterialTheme.shapes.extraLarge,
                color = MaterialTheme.colorScheme.primaryContainer
            ) {
                if (profile.profilePhoto != null) {
                    AsyncImage(
                        model = ImageRequest.Builder(LocalContext.current)
                            .data(profile.profilePhoto)
                            .crossfade(true)
                            .build(),
                        contentDescription = "Profile Photo",
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = profile.fullName.firstOrNull()?.toString() ?: "S",
                            style = MaterialTheme.typography.displaySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }
            FilledIconButton(
                onClick = onPhotoEdit,
                modifier = Modifier.align(Alignment.BottomEnd).size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CameraAlt,
                    contentDescription = "Edit Photo",
                    modifier = Modifier.size(16.dp)
                )
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(
            text = profile.fullName,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "ID: ${profile.studentId}",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun ProfileSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        CampusCard {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                content = content
            )
        }
    }
}

@Composable
fun ProfileItem(label: String, value: String) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Medium
        )
    }
}
