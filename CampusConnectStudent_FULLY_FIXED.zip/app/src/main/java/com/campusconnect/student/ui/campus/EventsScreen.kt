package com.campusconnect.student.ui.campus

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.campusconnect.student.data.model.CampusEvent
import com.campusconnect.student.ui.common.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EventsScreen(
    viewModel: EventsViewModel,
    onBackClick: () -> Unit
) {
    val uiState by viewModel.uiState
    val events by viewModel.events

    Scaffold(
        topBar = {
            CampusAppBar(
                title = "Campus Events",
                navigationIcon = Icons.Default.ArrowBack,
                onNavigationClick = onBackClick
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (uiState) {
                is EventsUiState.Loading -> LoadingState()
                else -> {
                    if (events.isEmpty()) {
                        EmptyState(message = "No upcoming events.")
                    } else {
                        EventsList(events, viewModel::toggleRegistration)
                    }
                }
            }
        }
    }
}

@Composable
fun EventsList(
    events: List<CampusEvent>,
    onToggleRegistration: (CampusEvent) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        items(events) { event ->
            EventItem(event, onToggleRegistration)
        }
    }
}

@Composable
fun EventItem(
    event: CampusEvent,
    onToggleRegistration: (CampusEvent) -> Unit
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large
    ) {
        Column {
            if (event.imageUrl != null) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(event.imageUrl)
                        .crossfade(true)
                        .build(),
                    contentDescription = null,
                    modifier = Modifier.fillMaxWidth().height(160.dp),
                    contentScale = ContentScale.Crop
                )
            }
            
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = event.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = "By ${event.organizer}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                
                Spacer(modifier = Modifier.height(12.dp))
                
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "${event.startDateTime} | ${event.endDateTime ?: ""}", style = MaterialTheme.typography.bodySmall)
                    
                    Spacer(modifier = Modifier.width(16.dp))
                    
                    Icon(imageVector = Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = event.location, style = MaterialTheme.typography.bodySmall)
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                Text(text = event.description, style = MaterialTheme.typography.bodyMedium, maxLines = 3)
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Button(
                    onClick = { onToggleRegistration(event) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = if (event.isRegistered) ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary) else ButtonDefaults.buttonColors()
                ) {
                    Text(text = if (event.isRegistered) "Cancel Registration" else "Register Now")
                }
            }
        }
    }
}
