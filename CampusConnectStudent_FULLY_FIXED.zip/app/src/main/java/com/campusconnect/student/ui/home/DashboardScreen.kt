package com.campusconnect.student.ui.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.campusconnect.student.data.model.DashboardData
import com.campusconnect.student.data.model.StudentUser
import com.campusconnect.student.ui.common.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel,
    onNotificationClick: () -> Unit,
    onProfileClick: () -> Unit
) {
    val uiState by viewModel.uiState
    val profile by viewModel.studentProfile

    Scaffold(
        topBar = {
            CampusAppBar(
                title = "Dashboard",
                actions = {
                    IconButton(onClick = onNotificationClick) {
                        Icon(imageVector = Icons.Default.Notifications, contentDescription = "Notifications")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (uiState) {
                is DashboardUiState.Loading -> LoadingState()
                is DashboardUiState.Success -> {
                    val dashboard = (uiState as DashboardUiState.Success).data.data
                    if (dashboard != null) {
                        DashboardContent(
                            profile = profile,
                            data = dashboard,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        EmptyState(message = "No dashboard data available.")
                    }
                }
                is DashboardUiState.Error -> ErrorState(
                    message = (uiState as DashboardUiState.Error).message,
                    onRetry = { viewModel.refreshDashboard() }
                )
                is DashboardUiState.Empty -> EmptyState(message = "No dashboard data available.")
            }
        }
    }
}

@Composable
fun DashboardContent(
    profile: StudentUser?,
    data: DashboardData,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            HeaderSection(profile)
        }
        item {
            StatsSection(data)
        }
        item {
            Text(
                text = "Academic Overview",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
        // Additional sections for upcoming activities could go here
    }
}

@Composable
fun HeaderSection(profile: StudentUser?) {
    CampusCard {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Surface(
                modifier = Modifier.size(60.dp),
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.primaryContainer
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = profile?.fullName?.firstOrNull()?.toString() ?: "S",
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column {
                Text(
                    text = profile?.fullName ?: "Student Name",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${profile?.departmentName ?: "Department"} | Sem ${profile?.semesterNumber ?: "-"}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "ID: ${profile?.studentId ?: "-"}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun StatsSection(data: DashboardData) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard(
                label = "Attendance",
                value = "${data.attendance?.percentage ?: 0f}%",
                modifier = Modifier.weight(1f)
            )
            StatCard(
                label = "CGPA",
                value = data.academics?.cgpa?.toString() ?: "-",
                modifier = Modifier.weight(1f)
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard(
                label = "Assignments",
                value = data.pendingAssignmentsCount.toString(),
                modifier = Modifier.weight(1f)
            )
            StatCard(
                label = "Pending Fees",
                value = data.fees?.pending?.let { "₹$it" } ?: "-",
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    ElevatedCard(
        modifier = modifier,
        shape = MaterialTheme.shapes.medium
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = label, style = MaterialTheme.typography.labelMedium)
            Text(
                text = value,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}
