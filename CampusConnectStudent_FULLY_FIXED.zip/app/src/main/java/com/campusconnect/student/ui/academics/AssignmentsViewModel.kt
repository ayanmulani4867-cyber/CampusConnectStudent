package com.campusconnect.student.ui.academics

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.campusconnect.student.data.model.Assignment
import com.campusconnect.student.data.repository.AcademicsExtendedRepository
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import okhttp3.MultipartBody

sealed class AssignmentsUiState {
    object Loading : AssignmentsUiState()
    object Success : AssignmentsUiState()
    data class Error(val message: String) : AssignmentsUiState()
}

class AssignmentsViewModel(private val repository: AcademicsExtendedRepository) : ViewModel() {

    private val _uiState = mutableStateOf<AssignmentsUiState>(AssignmentsUiState.Loading)
    val uiState: State<AssignmentsUiState> = _uiState

    private val _assignments = mutableStateOf<List<Assignment>>(emptyList())
    val assignments: State<List<Assignment>> = _assignments

    init {
        observeData()
        refresh()
    }

    private fun observeData() {
        viewModelScope.launch {
            repository.assignments.collectLatest { _assignments.value = it }
        }
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.value = AssignmentsUiState.Loading
            val result = repository.refreshAssignments()
            result.onSuccess {
                _uiState.value = AssignmentsUiState.Success
            }.onFailure {
                _uiState.value = AssignmentsUiState.Error(it.message ?: "Failed to load assignments")
            }
        }
    }

    fun submitAssignment(assignmentId: Int, filePart: MultipartBody.Part) {
        viewModelScope.launch {
            _uiState.value = AssignmentsUiState.Loading
            val result = repository.submitAssignment(assignmentId, filePart)
            result.onSuccess {
                _uiState.value = AssignmentsUiState.Success
                // refresh is called inside repository
            }.onFailure {
                _uiState.value = AssignmentsUiState.Error(it.message ?: "Failed to submit assignment")
            }
        }
    }
}
