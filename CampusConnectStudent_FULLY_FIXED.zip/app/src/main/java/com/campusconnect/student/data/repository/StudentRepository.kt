package com.campusconnect.student.data.repository

import com.campusconnect.student.data.api.StudentApi
import com.campusconnect.student.data.database.StudentDao
import com.campusconnect.student.data.model.DashboardResponse
import com.campusconnect.student.data.model.DetailedProfile
import com.campusconnect.student.data.model.ProfileResponse
import com.campusconnect.student.data.model.StudentUser
import com.campusconnect.student.data.preferences.SessionManager
import kotlinx.coroutines.flow.Flow
import okhttp3.MultipartBody
import retrofit2.Response

class StudentRepository(
    private val studentApi: StudentApi,
    private val studentDao: StudentDao,
    private val sessionManager: SessionManager
) {
    val studentProfile: Flow<StudentUser?> = studentDao.getStudentProfile()

    suspend fun refreshProfile(): Result<StudentUser> {
        return try {
            val token = sessionManager.getAuthToken() ?: return Result.failure(Exception("Not authenticated"))
            val response = studentApi.getProfile("Bearer $token")
            if (response.isSuccessful && response.body() != null) {
                val profileResponse = response.body()!!
                if (profileResponse.success && profileResponse.profile != null) {
                    val studentUser = mapToStudentUser(profileResponse.profile)
                    studentDao.insertStudentProfile(studentUser)
                    Result.success(studentUser)
                } else {
                    Result.failure(Exception(profileResponse.message ?: "Failed to fetch profile"))
                }
            } else {
                Result.failure(Exception("Network error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun mapToStudentUser(profile: DetailedProfile): StudentUser {
        val academic = profile.academic

        return StudentUser(
            id = profile.id,
            fullName = profile.fullName,
            studentId = profile.studentId,
            rollNo = profile.rollNo,
            enrollmentNo = profile.enrollmentNo,
            admissionNo = profile.admissionNo,
            departmentId = academic?.departmentId,
            departmentName = academic?.departmentName,
            courseId = academic?.courseId,
            courseName = academic?.courseName,
            semesterId = academic?.semesterId,
            semesterNumber = academic?.semesterNumber,
            divisionId = academic?.divisionId,
            divisionName = academic?.divisionName,
            batch = profile.batch,
            status = profile.status,
            profilePhoto = profile.profilePhoto,
            email = profile.collegeEmail,
            phone = profile.mobile,
            gender = profile.gender,
            bloodGroup = profile.bloodGroup,
            guardianName = profile.parentInfo?.fatherName ?: profile.parentInfo?.motherName,
            guardianPhone = profile.parentInfo?.fatherPhone ?: profile.parentInfo?.motherPhone,
            role = "student"
        )
    }

    suspend fun getDashboard(): Result<DashboardResponse> {
        return try {
            val token = sessionManager.getAuthToken() ?: return Result.failure(Exception("Not authenticated"))
            val response = studentApi.getDashboard("Bearer $token")
            if (response.isSuccessful && response.body() != null) {
                Result.success(response.body()!!)
            } else {
                Result.failure(Exception("Network error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun uploadProfilePhoto(photoPart: MultipartBody.Part): Result<String> {
        return try {
            val token = sessionManager.getAuthToken() ?: return Result.failure(Exception("Not authenticated"))
            val response = studentApi.uploadProfilePhoto("Bearer $token", photoPart)
            if (response.isSuccessful && response.body() != null) {
                val body = response.body()!!
                if (body.success) {
                    refreshProfile() // Refresh profile to update Room
                    Result.success(body.message ?: "Photo uploaded")
                } else {
                    Result.failure(Exception(body.message ?: "Failed to upload photo"))
                }
            } else {
                Result.failure(Exception("Network error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
