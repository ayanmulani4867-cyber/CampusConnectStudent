package com.campusconnect.student.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName

data class LoginRequest(
    @SerializedName("email") val email: String,
    @SerializedName("password") val password: String
)

data class LoginResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("message") val message: String?,
    @SerializedName("token") val token: String?,
    @SerializedName("student") val student: StudentUser?,
    @SerializedName("user") val user: UserPayload?
)

data class UserPayload(
    @SerializedName("id") val id: Int,
    @SerializedName("username") val username: String,
    @SerializedName("email") val email: String,
    @SerializedName("role") val role: String,
    @SerializedName("full_name") val fullName: String,
    @SerializedName("profile_image") val profileImage: String?,
    @SerializedName("must_change_password") val mustChangePassword: Boolean = false
)

data class ProfileResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("message") val message: String?,
    @SerializedName("profile") val profile: DetailedProfile?
)

data class DetailedProfile(
    @SerializedName("id") val id: Int,
    @SerializedName("student_id") val studentId: String,
    @SerializedName("roll_no") val rollNo: String?,
    @SerializedName("enrollment_no") val enrollmentNo: String?,
    @SerializedName("admission_no") val admissionNo: String?,
    @SerializedName("full_name") val fullName: String,
    @SerializedName("dob") val dob: String?,
    @SerializedName("gender") val gender: String?,
    @SerializedName("blood_group") val bloodGroup: String?,
    @SerializedName("college_email") val collegeEmail: String,
    @SerializedName("personal_email") val personalEmail: String?,
    @SerializedName("mobile") val mobile: String?,
    @SerializedName("admission_date") val admissionDate: String?,
    @SerializedName("batch") val batch: String?,
    @SerializedName("status") val status: String,
    @SerializedName("profile_photo") val profilePhoto: String?,
    @SerializedName("academic") val academic: AcademicInfo?,
    @SerializedName("address") val address: AddressInfo?,
    @SerializedName("parent_info") val parentInfo: ParentInfo?,
    @SerializedName("emergency_contact") val emergencyContact: EmergencyInfo?
)

data class AcademicInfo(
    @SerializedName("department_id") val departmentId: Int?,
    @SerializedName("department_name") val departmentName: String?,
    @SerializedName("course_id") val courseId: Int?,
    @SerializedName("course_name") val courseName: String?,
    @SerializedName("semester_id") val semesterId: Int?,
    @SerializedName("semester_number") val semesterNumber: Int?,
    @SerializedName("division_id") val divisionId: Int?,
    @SerializedName("division_name") val divisionName: String?,
    @SerializedName("session_name") val sessionName: String?
)

data class AddressInfo(
    @SerializedName("current") val current: AddressDetails?,
    @SerializedName("permanent") val permanent: AddressDetails?
)

data class AddressDetails(
    @SerializedName("line1") val line1: String?,
    @SerializedName("line2") val line2: String?,
    @SerializedName("city") val city: String?,
    @SerializedName("district") val district: String?,
    @SerializedName("state") val state: String?,
    @SerializedName("country") val country: String?,
    @SerializedName("pincode") val pincode: String?
)

data class ParentInfo(
    @SerializedName("father_name") val fatherName: String?,
    @SerializedName("father_phone") val fatherPhone: String?,
    @SerializedName("mother_name") val motherName: String?,
    @SerializedName("mother_phone") val motherPhone: String?
)

data class EmergencyInfo(
    @SerializedName("name") val name: String?,
    @SerializedName("phone") val phone: String?,
    @SerializedName("relation") val relation: String?
)

@Entity(tableName = "student_profile")
data class StudentUser(
    @PrimaryKey @SerializedName("id") val id: Int,
    @SerializedName("full_name") val fullName: String,
    @SerializedName("student_id") val studentId: String,
    @SerializedName("roll_no") val rollNo: String?,
    @SerializedName("enrollment_no") val enrollmentNo: String?,
    @SerializedName("admission_no") val admissionNo: String?,
    @SerializedName("department_id") val departmentId: Int?,
    @SerializedName("department_name") val departmentName: String?,
    @SerializedName("course_id") val courseId: Int?,
    @SerializedName("course_name") val courseName: String?,
    @SerializedName("semester_id") val semesterId: Int?,
    @SerializedName("semester_number") val semesterNumber: Int?,
    @SerializedName("division_id") val divisionId: Int?,
    @SerializedName("division_name") val divisionName: String?,
    @SerializedName("batch") val batch: String?,
    @SerializedName("status") val status: String?,
    @SerializedName("profile_photo") val profilePhoto: String?,
    @SerializedName("college_email") val email: String?,
    @SerializedName("mobile") val phone: String?,
    @SerializedName("gender") val gender: String? = null,
    @SerializedName("blood_group") val bloodGroup: String? = null,
    @SerializedName("guardian_name") val guardianName: String? = null,
    @SerializedName("guardian_phone") val guardianPhone: String? = null,
    @SerializedName("role") val role: String? = "student"
)
