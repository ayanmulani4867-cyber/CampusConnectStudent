# Campus Connect Student — Build Status

The original project reached `:app:compileDebugKotlin` in GitHub Actions but failed because
several repositories/screens referenced properties that are not present in the current
Kotlin models.

The reported errors include mismatches in:
- StudentRepository.kt
- AssignmentsScreen.kt
- AttendanceScreen.kt
- ExamsScreen.kt
- TimetableScreen.kt
- EventsScreen.kt
- NoticesScreen.kt
- NotificationsScreen.kt
- NotificationsViewModel.kt
- DashboardScreen.kt
- DashboardViewModel.kt
- ProfileScreen.kt
- FeedbackViewModel.kt

Do not replace production API responses with dummy data. Fix the callers to match the
current model definitions, then run:

    ./gradlew assembleDebug

The production backend URL remains the project's existing configured URL.
