# Campus Connect API Integration Guide

This document outlines the REST API endpoints required by the Android Student Application to communicate with the Flask backend.

## Base URL
The base URL is configurable in `Constants.kt`.
- Development: `http://<local-ip>:5000/`
- Production: `https://campus-connect-student-backend.render.com/`

## Authentication

### Login
Authenticates a student and returns a JWT token.

- **Endpoint**: `/api/login`
- **Method**: `POST`
- **Request Body**:
  ```json
  {
    "student_id": "STU12345",
    "password": "your_password"
  }
  ```
- **Response (Success 200 OK)**:
  ```json
  {
    "success": true,
    "message": "Login successful",
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "student": {
      "id": "1",
      "name": "John Doe",
      "email": "john.doe@college.edu",
      "role": "student",
      "department": "Computer Science",
      "course": "B.Tech",
      "semester": 5
    }
  }
  ```
- **Response (Failure 401 Unauthorized)**:
  ```json
  {
    "success": false,
    "message": "Invalid student ID or password"
  }
  ```
- **Response (Failure 403 Forbidden)**:
  ```json
  {
    "success": false,
    "message": "This application is for students only."
  }
  ```

> [!IMPORTANT]
> **Backend Implementation Status**: 
> - The `/api/login` endpoint must verify the student's credentials and ensure their `role` is specifically `"student"`.
> - Admin, HOD, and Faculty roles should be denied access with a 403 status.

## Student Data

### Dashboard
Returns statistics and upcoming activities for the dashboard.

- **Endpoint**: `/api/student/dashboard`
- **Method**: `GET`
- **Header**: `Authorization: Bearer <token>`
- **Response (Success 200 OK)**:
  ```json
  {
    "success": true,
    "stats": {
      "attendance_percentage": 85.5,
      "current_sgpa": 8.2,
      "cgpa": 8.5,
      "pending_fees": 15000.0,
      "active_assignments_count": 3,
      "upcoming_exams_count": 1
    },
    "upcoming_timetable": [...],
    "active_assignments": [...],
    "upcoming_exams": [...],
    "latest_notices": [...]
  }
  ```

### Profile
Returns full profile details of the authenticated student.

- **Endpoint**: `/api/student/profile`
- **Method**: `GET`
- **Header**: `Authorization: Bearer <token>`
- **Response (Success 200 OK)**:
  ```json
  {
    "success": true,
    "student": {
      "id": "1",
      "name": "John Doe",
      "student_id": "STU12345",
      "email": "john.doe@college.edu",
      "phone": "+91 9876543210",
      "department": "Computer Science",
      ...
    }
  }
  ```

### Profile Photo Upload
Uploads/Replaces the student's profile photo.

- **Endpoint**: `/api/student/profile-photo`
- **Method**: `POST`
- **Header**: `Authorization: Bearer <token>`
- **Content-Type**: `multipart/form-data`
- **Body**: 
    - `photo`: File
- **Response (Success 200 OK)**:
  ```json
  {
    "success": true,
    "message": "Photo updated successfully",
    "student": { ... updated student object ... }
  }
  ```

## Academics

### Attendance
Returns subject-wise and overall attendance summary.

- **Endpoint**: `/api/student/attendance`
- **Method**: `GET`
- **Header**: `Authorization: Bearer <token>`
- **Response (Success 200 OK)**:
  ```json
  {
    "success": true,
    "summary": {
      "total_lectures": 200,
      "present_count": 170,
      "absent_count": 30,
      "percentage": 85.0
    },
    "subject_wise": [
      {
        "subject_code": "CS101",
        "subject_name": "Data Structures",
        "present": 45,
        "absent": 5,
        "total": 50,
        "percentage": 90.0
      }
    ],
    "history": [
      { "date": "2026-08-15", "subject_name": "Data Structures", "status": "Present" }
    ]
  }
  ```

### Results
Returns semester-wise grades and GPA.

- **Endpoint**: `/api/student/results`
- **Method**: `GET`
- **Header**: `Authorization: Bearer <token>`
- **Response (Success 200 OK)**:
  ```json
  {
    "success": true,
    "current_sgpa": 8.5,
    "cgpa": 8.2,
    "semesters": [
      {
        "semester_id": 5,
        "semester_no": 5,
        "sgpa": 8.5,
        "total_credits": 24,
        "is_published": true,
        "grades": [
          {
            "subject_code": "CS101",
            "subject_name": "Data Structures",
            "credits": 4,
            "marks": 85,
            "grade": "A+",
            "grade_point": 9,
            "status": "Pass"
          }
        ]
      }
    ]
  }
  ```

### Timetable
Returns the weekly timetable.

- **Endpoint**: `/api/student/timetable`
- **Method**: `GET`
- **Header**: `Authorization: Bearer <token>`
- **Response (Success 200 OK)**:
  ```json
  {
    "success": true,
    "timetable": [
      {
        "id": "t1",
        "day": "Monday",
        "time": "09:00-10:00",
        "subject_name": "Mathematics",
        "faculty_name": "Dr. Smith",
        "room": "Room 101",
        "division": "A"
      }
    ]
  }
  ```

## Extended Academics

### Assignments
Returns list of student assignments.

- **Endpoint**: `/api/student/assignments`
- **Method**: `GET`
- **Header**: `Authorization: Bearer <token>`
- **Response**:
  ```json
  {
    "success": true,
    "assignments": [
      {
        "id": "a1",
        "title": "Data Structures Assignment 1",
        "subject_name": "Data Structures",
        "faculty_name": "Prof. Alan",
        "description": "Implement a Linked List.",
        "deadline": "2026-09-01 23:59",
        "max_marks": 20,
        "attachment_url": "...",
        "status": "Not Submitted",
        "obtained_marks": null,
        "feedback": null,
        "submission_date": null
      }
    ]
  }
  ```

### Assignment Submission
Submits a file for an assignment.

- **Endpoint**: `/api/student/assignments/submit`
- **Method**: `POST`
- **Header**: `Authorization: Bearer <token>`
- **Content-Type**: `multipart/form-data`
- **Parameters**:
    - `assignment_id`: String
    - `file`: File
- **Response**:
  ```json
  {
    "success": true,
    "message": "Assignment submitted successfully",
    "assignment": { ... updated assignment object ... }
  }
  ```

### Study Materials
Returns subject-wise study materials.

- **Endpoint**: `/api/student/study-materials`
- **Method**: `GET`
- **Header**: `Authorization: Bearer <token>`
- **Response**:
  ```json
  {
    "success": true,
    "materials": [
      {
        "id": "m1",
        "title": "Introduction to Graphs",
        "subject_name": "Data Structures",
        "faculty_name": "Prof. Alan",
        "upload_date": "2026-08-10",
        "file_type": "PDF",
        "file_url": "..."
      }
    ]
  }
  ```

### Exams
Returns the exam schedule.

- **Endpoint**: `/api/student/exams`
- **Method**: `GET`
- **Header**: `Authorization: Bearer <token>`
- **Response**:
  ```json
  {
    "success": true,
    "exams": [
      {
        "id": "e1",
        "exam_type": "Mid-term",
        "subject_name": "Data Structures",
        "date": "2026-10-15",
        "time": "10:00 - 12:00",
        "room": "Lab 2",
        "semester": 5,
        "is_completed": false
      }
    ]
  }
  ```

## Services

### Fees
Returns fee summary and payment history.

- **Endpoint**: `/api/student/fees`
- **Method**: `GET`
- **Header**: `Authorization: Bearer <token>`
- **Response**:
  ```json
  {
    "success": true,
    "total_fees": 50000.0,
    "paid_amount": 35000.0,
    "pending_amount": 15000.0,
    "due_date": "2026-09-15",
    "status": "Partially Paid",
    "payment_history": [
      {
        "receipt_no": "REC9988",
        "date": "2026-07-10",
        "amount": 35000.0,
        "payment_type": "Online",
        "status": "Success",
        "receipt_url": "..."
      }
    ]
  }
  ```

### Leave History
Returns previous leave applications.

- **Endpoint**: `/api/student/leave/history`
- **Method**: `GET`
- **Header**: `Authorization: Bearer <token>`
- **Response**:
  ```json
  {
    "success": true,
    "leaves": [
      {
        "id": "L1",
        "leave_type": "Sick Leave",
        "start_date": "2026-08-01",
        "end_date": "2026-08-03",
        "reason": "Fever",
        "status": "Approved",
        "applied_on": "2026-07-30",
        "approver_name": "Dr. Miller",
        "comments": "Get well soon",
        "attachment_url": null
      }
    ]
  }
  ```

### Apply for Leave
Submits a new leave application.

- **Endpoint**: `/api/student/leave/apply`
- **Method**: `POST`
- **Header**: `Authorization: Bearer <token>`
- **Request Body**:
  ```json
  {
    "leave_type": "Academic",
    "start_date": "2026-09-10",
    "end_date": "2026-09-12",
    "reason": "Workshop attendance"
  }
  ```
- **Response**:
  ```json
  {
    "success": true,
    "message": "Leave application submitted",
    "leave": { ... new leave object ... }
  }
  ```

### Submit Feedback
Submits faculty or general feedback.

- **Endpoint**: `/api/student/feedback`
- **Method**: `POST`
- **Header**: `Authorization: Bearer <token>`
- **Request Body**:
  ```json
  {
    "type": "Faculty",
    "target_id": "F101",
    "rating": 5,
    "comments": "Excellent teaching style"
  }
  ```
- **Response**:
  ```json
  {
    "success": true,
    "message": "Thank you for your feedback"
  }
  ```

## Campus

### Certificates
Returns student's certificate requests.

- **Endpoint**: `/api/student/certificates`
- **Method**: `GET`
- **Header**: `Authorization: Bearer <token>`
- **Response**:
  ```json
  {
    "success": true,
    "certificates": [
      {
        "id": "C1",
        "type": "Bonafide Certificate",
        "requested_on": "2026-08-10",
        "status": "Approved",
        "approved_on": "2026-08-12",
        "download_url": "..."
      }
    ]
  }
  ```

### Request Certificate
Submits a new certificate request.

- **Endpoint**: `/api/student/certificates/request`
- **Method**: `POST`
- **Header**: `Authorization: Bearer <token>`
- **Request Body**:
  ```json
  {
    "type": "Leaving Certificate",
    "reason": "Course completion"
  }
  ```

### Complaints
Returns student's grievance history.

- **Endpoint**: `/api/student/complaints`
- **Method**: `GET`
- **Header**: `Authorization: Bearer <token>`
- **Response**:
  ```json
  {
    "success": true,
    "complaints": [
      {
        "id": "TKT1001",
        "category": "Infrastructure",
        "title": "Broken Lab Chair",
        "description": "Chair in Lab 3 is broken.",
        "status": "Resolved",
        "created_at": "2026-08-05",
        "updated_at": "2026-08-07",
        "resolution_comments": "Chair replaced."
      }
    ]
  }
  ```

### Create Complaint
Submits a new grievance.

- **Endpoint**: `/api/student/complaints/create`
- **Method**: `POST`
- **Header**: `Authorization: Bearer <token>`
- **Request Body**:
  ```json
  {
    "category": "Academic",
    "title": "Library Book Issue",
    "description": "..."
  }
  ```

### Events
Returns campus events.

- **Endpoint**: `/api/student/events`
- **Method**: `GET`
- **Header**: `Authorization: Bearer <token>`
- **Response**:
  ```json
  {
    "success": true,
    "events": [
      {
        "id": "E1",
        "title": "Tech Fest 2026",
        "description": "Annual technology festival.",
        "date": "2026-09-20",
        "time": "10:00 AM",
        "location": "Main Auditorium",
        "organizer": "Student Council",
        "is_registered": false,
        "image_url": "..."
      }
    ]
  }
  ```

### Register for Event
Toggles event registration.

- **Endpoint**: `/api/student/events/register`
- **Method**: `POST`
- **Header**: `Authorization: Bearer <token>`
- **Request Body**:
  ```json
  {
    "event_id": "E1",
    "action": "Register"
  }
  ```

## Communications

### Notice Board
Returns list of official notices.

- **Endpoint**: `/api/student/notices`
- **Method**: `GET`
- **Header**: `Authorization: Bearer <token>`
- **Response**:
  ```json
  {
    "success": true,
    "notices": [
      {
        "id": "N1",
        "title": "Semester Exams Postponed",
        "description": "Due to holiday, exams are moved to...",
        "category": "Examination",
        "published_date": "2026-08-14",
        "expiry_date": "2026-08-20",
        "attachment_url": "..."
      }
    ]
  }
  ```

### Notifications
Returns student's app notifications.

- **Endpoint**: `/api/student/notifications`
- **Method**: `GET`
- **Header**: `Authorization: Bearer <token>`
- **Response**:
  ```json
  {
    "success": true,
    "unread_count": 2,
    "notifications": [
      {
        "id": "NT1",
        "title": "Leave Approved",
        "message": "Your leave for 2026-08-15 has been approved.",
        "type": "Leave",
        "timestamp": "2026-08-15 10:00 AM",
        "is_read": false
      }
    ]
  }
  ```

### Mark as Read
Marks notification as read.

- **Endpoint**: `/api/student/notifications/read`
- **Method**: `POST`
- **Header**: `Authorization: Bearer <token>`
- **Request Body**:
  ```json
  {
    "notification_id": "NT1",
    "mark_all": false
  }
  ```

### Sync FCM Token
Registers device token for push notifications.

- **Endpoint**: `/api/student/notifications/token`
- **Method**: `POST`
- **Header**: `Authorization: Bearer <token>`
- **Request Body**:
  ```json
  {
    "fcm_token": "..."
  }
  ```

## Future Endpoints (To be implemented)
- `GET /api/student/profile`
- `GET /api/student/attendance`
- `GET /api/student/results`
- `GET /api/student/timetable`
- `POST /api/student/assignments/submit`
- `GET /api/student/fees`
- `POST /api/student/leave/apply`
- `GET /api/student/notices`
- `POST /api/student/feedback`
