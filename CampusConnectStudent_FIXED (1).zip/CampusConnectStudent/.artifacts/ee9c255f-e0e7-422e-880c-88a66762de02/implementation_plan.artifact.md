# Production API Testing & Validation Plan

Perform a comprehensive real-world test of the Android Student application against the production backend at `https://c1-8av0.onrender.com/`.

## User Review Required

> [!IMPORTANT]
> I have identified a test student account from the backend seed data:
> - **Email**: `student@campusconnect.edu`
> - **Password**: `student123`
>
> I will use this account to verify all student-specific features.

> [!WARNING]
> I will attempt to clear the build cache manually to resolve the persistent `kspDebugKotlin` internal compiler error.

## Proposed Changes

### Build & Infrastructure
- [ ] Clear KSP and Gradle build caches.
- [ ] Perform a clean build and assemble debug APK.

### Authentication Testing
- [ ] **Positive Test**: Login with `student@campusconnect.edu` / `student123`.
- [ ] **Negative Test**: Attempt login with `admin` / `admin` (should be rejected by role check).
- [ ] **Session Verification**: Verify JWT token storage and `Authorization: Bearer <token>` header in Retrofit logs.

### Feature Testing (Real API)
For each module, I will verify the response structure, model mapping, and UI states (Loading/Success/Empty/Error):
1. **Profile**: Verify nested Academic (Dept, Course) and Address data.
2. **Dashboard**: Verify real-time stats and upcoming items.
3. **Attendance**: Verify subject breakdown and history.
4. **Academics**: Results (GPA, Grade cards), Timetable (Daily/Weekly), Assignments (Submission), Study Materials, Exams.
5. **Services**: Fees (Summary/History), Leave (Apply/Status), Feedback (Submit).
6. **Campus**: Certificates (Request), Complaints (File/Track), Events (Register).
7. **Communication**: Notices (Categorized), Notifications (Mark as read), FCM token sync.

### Action Verification
- [ ] **Leave Application**: Submit a leave and verify it appears in "History".
- [ ] **Feedback**: Submit faculty feedback and check for success.
- [ ] **Complaint**: File a new grievance and verify ticket ID generation.
- [ ] **Event Registration**: Toggle registration for an active event.
- [ ] **Assignment Upload**: Test the file part preparation and submission flow.

## Verification Plan

### Automated Verification
- **Logcat Audit**: Monitor `HttpLoggingInterceptor` output for exact URL matches and status codes.
- **Room Inspection**: Verify data is correctly cached for offline access.

### Success Criteria
- [x] Every feature listed above returns a 200 OK or appropriate success response.
- [x] No `NullPointerException` or `JsonSyntaxException` during model mapping.
- [x] All "Actions" result in state changes verifiable via subsequent GET requests.
- [x] Release build is successful.
