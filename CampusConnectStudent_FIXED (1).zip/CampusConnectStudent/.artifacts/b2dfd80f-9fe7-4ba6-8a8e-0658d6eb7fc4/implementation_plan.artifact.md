# Implementation Plan - Phase 8: Campus Communications (Notices, Notifications, FCM)

This phase implements the communication layer of the application, including a categorized Notice Board, a Notification Center, and integration with Firebase Cloud Messaging (FCM) for real-time alerts.

## User Review Required

> [!IMPORTANT]
> - **Firebase Setup**: I will add the FCM dependencies and create the `FirebaseMessagingService` class. However, for real push notifications to work, you will need to add a valid `google-services.json` file to the `app/` directory and configure the project in the Firebase Console.
> - **Notification Center**: This will include "Mark as Read" functionality and an unread count.
> - **Database Version**: Incrementing Room database version to 7.

## Proposed Changes

### 1. Build Configuration
#### [MODIFY] [libs.versions.toml](file:///C:/Users/ayanm/AndroidStudioProjects/CampusConnectStudent/gradle/libs.versions.toml)
- Add Firebase BOM and Messaging dependencies.
#### [MODIFY] [build.gradle.kts (app)](file:///C:/Users/ayanm/AndroidStudioProjects/CampusConnectStudent/app/build.gradle.kts)
- Apply Firebase dependencies.

### 2. Data Layer (Models & API)
#### [NEW] `data/model/CommunicationModels.kt`
- **Notices**: `Notice`, `NoticeResponse`.
- **Notifications**: `AppNotification`, `NotificationResponse`.
#### [NEW] `data/api/CommunicationApi.kt`
- `GET /api/student/notices`
- `GET /api/student/notifications`
- `POST /api/student/notifications/read` (Mark single/all as read)
- `POST /api/student/notifications/token` (Sync FCM token to Flask)

### 3. Database Layer (Room)
#### [NEW] `data/database/CommunicationDaos.kt`
- `NoticeDao`, `NotificationDao`.
#### [MODIFY] `data/database/AppDatabase.kt`
- Register new entities and increment version to 7.

### 4. Firebase Integration
#### [NEW] `data/api/CampusMessagingService.kt`
- Extends `FirebaseMessagingService`.
- Handles token refresh and incoming messages.
- Triggers local notifications.

### 5. Repository Layer
#### [NEW] `data/repository/CommunicationRepository.kt`
- Manages synchronization of notices and notifications.
- Handles FCM token registration with the backend.

### 6. UI Layer (MVVM)
#### [NEW] `ui/campus/NoticesScreen.kt` & `NoticesViewModel.kt`
- Categorized list (College, Dept, Class).
- Search/Filter functionality.
#### [NEW] `ui/campus/NotificationsScreen.kt` & `NotificationsViewModel.kt`
- List of alerts with "Mark as Read" swipe or button.
- Clear distinction between read/unread states.

### 7. Navigation Integration
#### [MODIFY] `navigation/NavGraph.kt`
- Replace placeholders for Notices and Notifications with real screens.

## Verification Plan

### Automated Tests
1. Run `gradle_sync`.
2. Run `gradle_build`.

### Manual Verification
- Verify notice categorization logic.
- Test "Mark as Read" functionality in the Notification center.
- Verify that the FCM token is generated and logged (waiting for server sync logic).
- Ensure data remains available offline.
