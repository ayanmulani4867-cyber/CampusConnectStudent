# Phase 8: Campus Communications (Notices, Notifications, FCM)

- [x] Add Firebase dependencies to `libs.versions.toml`
- [x] Update `app/build.gradle.kts` with Firebase Messaging
- [x] Create `CommunicationModels.kt` (Notices, Notifications)
- [x] Create `CommunicationApi.kt` interface
- [x] Implement `NoticeDao` and `NotificationDao`
- [x] Update `AppDatabase.kt` (Entities + Version Bump to 7)
- [x] Create `CampusMessagingService.kt`
- [x] Implement `CommunicationRepository.kt`
- [x] Update `CampusApp.kt` with `CommunicationRepository`
- [x] Implement `NoticesViewModel.kt` and `NoticesScreen.kt`
- [x] Implement `NotificationsViewModel.kt` and `NotificationsScreen.kt`
- [x] Update `NavGraph.kt` with new routes
- [x] Update `API_INTEGRATION.md` with new endpoints
- [x] Verify build and fix errors
- [x] Manual verification (Real-time token log, Read status, Offline support)
