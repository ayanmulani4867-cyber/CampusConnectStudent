package com.campusconnect.student.data.api

import com.campusconnect.student.data.model.*
import com.google.gson.annotations.SerializedName
import okhttp3.MultipartBody
import retrofit2.Response
import retrofit2.http.*

interface StudentApi {
    @GET("api/student/profile")
    suspend fun getProfile(@Header("Authorization") token: String): Response<ProfileResponse>

    @PATCH("api/student/profile")
    suspend fun updateProfile(
        @Header("Authorization") token: String,
        @Body request: Map<String, String>
    ): Response<BaseResponse>

    @GET("api/student/dashboard")
    suspend fun getDashboard(@Header("Authorization") token: String): Response<DashboardResponse>

    @Multipart
    @POST("api/student/profile-photo")
    suspend fun uploadProfilePhoto(
        @Header("Authorization") token: String,
        @Part photo: MultipartBody.Part
    ): Response<PhotoUploadResponse>

    @GET("api/student/id-card")
    suspend fun getIdCard(@Header("Authorization") token: String): Response<IdCardResponse>
}

data class PhotoUploadResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("message") val message: String?,
    @SerializedName("profile_photo") val profilePhoto: String?
)

data class IdCardResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("id_card") val data: IdCardData?
)

data class IdCardData(
    @SerializedName("student_id") val studentId: String,
    @SerializedName("full_name") val fullName: String,
    @SerializedName("qr_verification_code") val qrCode: String,
    @SerializedName("profile_photo") val photo: String?
)
