package com.campusconnect.student.ui.campus

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.campusconnect.student.data.model.AppNotification
import com.campusconnect.student.data.repository.CommunicationRepository
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

sealed class NotificationsUiState {
    object Loading : NotificationsUiState()
    object Success : NotificationsUiState()
    data class Error(val message: String) : NotificationsUiState()
}

class NotificationsViewModel(private val repository: CommunicationRepository) : ViewModel() {

    private val _uiState = mutableStateOf<NotificationsUiState>(NotificationsUiState.Loading)
    val uiState: State<NotificationsUiState> = _uiState

    private val _notifications = mutableStateOf<List<AppNotification>>(emptyList())
    val notifications: State<List<AppNotification>> = _notifications

    init {
        observeData()
        refresh()
    }

    private fun observeData() {
        viewModelScope.launch {
            repository.notifications.collectLatest {
                _notifications.value = it
            }
        }
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.value = NotificationsUiState.Loading
            val result = repository.refreshNotifications()
            result.onSuccess {
                _uiState.value = NotificationsUiState.Success
            }.onFailure {
                _uiState.value = NotificationsUiState.Error(it.message ?: "Failed to load notifications")
            }
        }
    }

    fun markAsRead(notificationId: String) {
        viewModelScope.launch {
            repository.markAsRead(notificationId = notificationId)
        }
    }

    fun markAllAsRead() {
        viewModelScope.launch {
            repository.markAsRead(markAll = true)
        }
    }
}
