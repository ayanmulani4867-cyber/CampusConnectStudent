package com.campusconnect.student.ui.campus

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.campusconnect.student.navigation.Screen
import com.campusconnect.student.ui.common.CampusAppBar

data class CampusFeature(
    val title: String,
    val icon: ImageVector,
    val route: String
)

val campusFeatures = listOf(
    CampusFeature("Certificates", Icons.Default.CardMembership, Screen.Certificates.route),
    CampusFeature("Complaints", Icons.Default.ReportProblem, Screen.Complaints.route),
    CampusFeature("Events", Icons.Default.Event, Screen.Events.route),
    CampusFeature("Notices", Icons.Default.Announcement, Screen.Notices.route),
    CampusFeature("Notifications", Icons.Default.Notifications, Screen.Notifications.route)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CampusHubScreen(
    onFeatureClick: (String) -> Unit
) {
    Scaffold(
        topBar = {
            CampusAppBar(title = "Campus Hub")
        }
    ) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(campusFeatures) { feature ->
                CampusCard(feature, onFeatureClick)
            }
        }
    }
}

@Composable
fun CampusCard(feature: CampusFeature, onClick: (String) -> Unit) {
    ElevatedCard(
        onClick = { onClick(feature.route) },
        modifier = Modifier.fillMaxWidth().height(140.dp),
        shape = MaterialTheme.shapes.large
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = feature.icon,
                contentDescription = null,
                modifier = Modifier.size(40.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = feature.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
