package com.campusconnect.student.data.database

import androidx.room.*
import com.campusconnect.student.data.model.AttendanceRecord
import com.campusconnect.student.data.model.SemesterResult
import com.campusconnect.student.data.model.SubjectAttendance
import com.campusconnect.student.data.model.TimetableEntry
import kotlinx.coroutines.flow.Flow

@Dao
interface AttendanceDao {
    @Query("SELECT * FROM subject_attendance")
    fun getSubjectAttendance(): Flow<List<SubjectAttendance>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubjectAttendance(list: List<SubjectAttendance>)

    @Query("SELECT * FROM attendance_history ORDER BY date DESC")
    fun getAttendanceHistory(): Flow<List<AttendanceRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttendanceHistory(list: List<AttendanceRecord>)

    @Query("DELETE FROM subject_attendance")
    suspend fun clearSubjectAttendance()

    @Query("DELETE FROM attendance_history")
    suspend fun clearAttendanceHistory()
}

@Dao
interface ResultDao {
    @Query("SELECT * FROM semester_results ORDER BY semesterNo DESC")
    fun getResults(): Flow<List<SemesterResult>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertResults(list: List<SemesterResult>)

    @Query("DELETE FROM semester_results")
    suspend fun clearResults()
}

@Dao
interface TimetableDao {
    @Query("SELECT * FROM timetable")
    fun getTimetable(): Flow<List<TimetableEntry>>

    @Query("SELECT * FROM timetable WHERE day = :day")
    fun getTimetableForDay(day: String): Flow<List<TimetableEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTimetable(list: List<TimetableEntry>)

    @Query("DELETE FROM timetable")
    suspend fun clearTimetable()
}
