package com.campusconnect.student.utils

object Constants {
    // API
    const val BASE_URL = "https://c1-8av0.onrender.com/"
    const val API_TIMEOUT = 30L

    // Preferences
    const val PREFS_NAME = "campus_connect_prefs"
    const val KEY_AUTH_TOKEN = "auth_token"
    const val KEY_STUDENT_ID = "student_id"

    // Database
    const val DATABASE_NAME = "campus_connect_db"
}
