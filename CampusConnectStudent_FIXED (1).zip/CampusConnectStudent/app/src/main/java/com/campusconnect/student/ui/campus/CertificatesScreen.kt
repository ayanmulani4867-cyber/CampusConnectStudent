package com.campusconnect.student.ui.campus

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.campusconnect.student.data.model.CertificateRecord
import com.campusconnect.student.ui.common.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CertificatesScreen(
    viewModel: CertificatesViewModel,
    onBackClick: () -> Unit
) {
    val uiState by viewModel.uiState
    val certificates by viewModel.certificates
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("My Certificates", "Request")

    Scaffold(
        topBar = {
            CampusAppBar(
                title = "Certificates",
                navigationIcon = Icons.Default.ArrowBack,
                onNavigationClick = onBackClick
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            TabRow(selectedTabIndex = selectedTab) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title) }
                    )
                }
            }

            when (selectedTab) {
                0 -> CertificateList(certificates)
                1 -> RequestCertificateForm(viewModel)
            }
        }
    }

    if (uiState is CertificatesUiState.Success) {
        AlertDialog(
            onDismissRequest = { viewModel.resetState() },
            title = { Text("Request Submitted") },
            text = { Text("Your certificate request has been submitted for approval.") },
            confirmButton = {
                TextButton(onClick = { 
                    viewModel.resetState()
                    selectedTab = 0 
                }) {
                    Text("OK")
                }
            }
        )
    }
}

@Composable
fun CertificateList(certificates: List<CertificateRecord>) {
    if (certificates.isEmpty()) {
        EmptyState(message = "No certificates requested yet.")
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(certificates) { cert ->
                CertificateItem(cert)
            }
        }
    }
}

@Composable
fun CertificateItem(cert: CertificateRecord) {
    val context = LocalContext.current
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = cert.type, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(text = "Requested: ${cert.requestedOn}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            
            StatusBadge(cert.status)
            
            if (cert.status.lowercase() == "approved" && cert.downloadUrl != null) {
                IconButton(onClick = { 
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(cert.downloadUrl))
                    context.startActivity(intent)
                }) {
                    Icon(imageVector = Icons.Default.Download, contentDescription = "Download")
                }
            }
        }
    }
}

@Composable
fun StatusBadge(status: String) {
    val color = when (status.lowercase()) {
        "approved" -> Color(0xFF4CAF50)
        "rejected" -> Color(0xFFF44336)
        "pending" -> Color(0xFFFF9800)
        else -> MaterialTheme.colorScheme.outline
    }
    Surface(
        color = color.copy(alpha = 0.1f),
        shape = MaterialTheme.shapes.extraSmall
    ) {
        Text(
            text = status,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun RequestCertificateForm(viewModel: CertificatesViewModel) {
    var certType by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    val uiState by viewModel.uiState

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        OutlinedTextField(
            value = certType,
            onValueChange = { certType = it },
            label = { Text("Certificate Type (e.g. Bonafide, Leaving)") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = reason,
            onValueChange = { reason = it },
            label = { Text("Reason for Request") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3
        )
        
        if (uiState is CertificatesUiState.Error) {
            Text(text = (uiState as CertificatesUiState.Error).message, color = MaterialTheme.colorScheme.error)
        }

        Spacer(modifier = Modifier.weight(1f))

        Button(
            onClick = { viewModel.requestCertificate(certType, reason) },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            enabled = uiState !is CertificatesUiState.Loading
        ) {
            if (uiState is CertificatesUiState.Loading) {
                CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
            } else {
                Text("Submit Request")
            }
        }
    }
}
