package com.campusconnect.student.data.model

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName

data class AssignmentResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("assignments") val assignments: List<Assignment>?
)

@Entity(tableName = "assignments")
data class Assignment(
    @PrimaryKey @SerializedName("id") val id: Int,
    @SerializedName("title") val title: String,
    @SerializedName("subject_name") val subjectName: String,
    @SerializedName("subject_code") val subjectCode: String?,
    @SerializedName("faculty_name") val facultyName: String,
    @SerializedName("description") val description: String?,
    @SerializedName("due_date") val deadline: String,
    @SerializedName("max_marks") val maxMarks: Double,
    @SerializedName("attachment_url") val attachmentUrl: String?,
    @Embedded @SerializedName("submission") val submission: SubmissionInfo?
)

data class SubmissionInfo(
    @SerializedName("is_submitted") val isSubmitted: Boolean,
    @SerializedName("status") val status: String, // "Pending", "Submitted", "Overdue", "Graded"
    @SerializedName("submitted_at") val submittedAt: String?,
    @SerializedName("submission_text") val submissionText: String?,
    @SerializedName("submission_file") val submissionFile: String?,
    @SerializedName("marks_obtained") val obtainedMarks: Double?,
    @SerializedName("feedback") val feedback: String?,
    @SerializedName("evaluated_at") val evaluatedAt: String?
)

data class SubmissionResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("message") val message: String?,
    @SerializedName("submission_id") val submissionId: Int?,
    @SerializedName("status") val status: String?
)
