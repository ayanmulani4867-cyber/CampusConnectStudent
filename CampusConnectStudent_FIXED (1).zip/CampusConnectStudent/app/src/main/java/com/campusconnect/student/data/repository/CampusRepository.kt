package com.campusconnect.student.data.repository

import com.campusconnect.student.data.api.CampusApi
import com.campusconnect.student.data.database.CertificateDao
import com.campusconnect.student.data.database.ComplaintDao
import com.campusconnect.student.data.database.EventDao
import com.campusconnect.student.data.model.*
import com.campusconnect.student.data.preferences.SessionManager
import kotlinx.coroutines.flow.Flow

class CampusRepository(
    private val api: CampusApi,
    private val certificateDao: CertificateDao,
    private val complaintDao: ComplaintDao,
    private val eventDao: EventDao,
    private val sessionManager: SessionManager
) {
    // Certificates
    val certificates: Flow<List<CertificateRecord>> = certificateDao.getCertificates()

    suspend fun refreshCertificates(): Result<List<CertificateRecord>> {
        return try {
            val token = sessionManager.getAuthToken() ?: return Result.failure(Exception("Not authenticated"))
            val response = api.getCertificates("Bearer $token")
            if (response.isSuccessful && response.body() != null) {
                val data = response.body()!!
                if (data.success && data.certificates != null) {
                    certificateDao.insertCertificates(data.certificates)
                    Result.success(data.certificates)
                } else {
                    Result.failure(Exception("Failed to fetch certificates"))
                }
            } else {
                Result.failure(Exception("Network error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun requestCertificate(type: String, reason: String): Result<String> {
        return try {
            val token = sessionManager.getAuthToken() ?: return Result.failure(Exception("Not authenticated"))
            val response = api.requestCertificate("Bearer $token", CertificateRequest(type, reason))
            if (response.isSuccessful && response.body() != null) {
                val data = response.body()!!
                if (data.success) {
                    Result.success(data.message ?: "Request submitted successfully")
                } else {
                    Result.failure(Exception(data.message ?: "Failed to submit request"))
                }
            } else {
                Result.failure(Exception("Network error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Complaints
    val complaints: Flow<List<ComplaintRecord>> = complaintDao.getComplaints()

    suspend fun refreshComplaints(): Result<List<ComplaintRecord>> {
        return try {
            val token = sessionManager.getAuthToken() ?: return Result.failure(Exception("Not authenticated"))
            val response = api.getComplaints("Bearer $token")
            if (response.isSuccessful && response.body() != null) {
                val data = response.body()!!
                if (data.success && data.complaints != null) {
                    complaintDao.insertComplaints(data.complaints)
                    Result.success(data.complaints)
                } else {
                    Result.failure(Exception("Failed to fetch complaints"))
                }
            } else {
                Result.failure(Exception("Network error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createComplaint(category: String, title: String, description: String): Result<String> {
        return try {
            val token = sessionManager.getAuthToken() ?: return Result.failure(Exception("Not authenticated"))
            val response = api.createComplaint("Bearer $token", ComplaintCreateRequest(category, title, description))
            if (response.isSuccessful && response.body() != null) {
                val data = response.body()!!
                if (data.success) {
                    Result.success(data.message ?: "Complaint submitted successfully")
                } else {
                    Result.failure(Exception(data.message ?: "Failed to submit complaint"))
                }
            } else {
                Result.failure(Exception("Network error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Events
    val events: Flow<List<CampusEvent>> = eventDao.getEvents()

    suspend fun refreshEvents(): Result<List<CampusEvent>> {
        return try {
            val token = sessionManager.getAuthToken() ?: return Result.failure(Exception("Not authenticated"))
            val response = api.getEvents("Bearer $token")
            if (response.isSuccessful && response.body() != null) {
                val data = response.body()!!
                if (data.success && data.events != null) {
                    eventDao.insertEvents(data.events)
                    Result.success(data.events)
                } else {
                    Result.failure(Exception("Failed to fetch events"))
                }
            } else {
                Result.failure(Exception("Network error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun registerForEvent(eventId: Int, register: Boolean): Result<String> {
        return try {
            val token = sessionManager.getAuthToken() ?: return Result.failure(Exception("Not authenticated"))
            val action = if (register) "Register" else "Cancel"
            val response = api.registerForEvent("Bearer $token", EventRegisterRequest(eventId, action))
            if (response.isSuccessful && response.body() != null) {
                val data = response.body()!!
                if (data.success) {
                    refreshEvents()
                    Result.success(data.message ?: "Action successful")
                } else {
                    Result.failure(Exception(data.message ?: "Action failed"))
                }
            } else {
                Result.failure(Exception("Network error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
