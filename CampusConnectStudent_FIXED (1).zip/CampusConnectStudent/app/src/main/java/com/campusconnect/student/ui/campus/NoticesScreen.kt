package com.campusconnect.student.ui.campus

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.campusconnect.student.data.model.Notice
import com.campusconnect.student.ui.common.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoticesScreen(
    viewModel: NoticesViewModel,
    onBackClick: () -> Unit
) {
    val uiState by viewModel.uiState
    val notices by viewModel.notices
    val selectedCategory by viewModel.selectedCategory

    Scaffold(
        topBar = {
            CampusAppBar(
                title = "Notice Board",
                navigationIcon = Icons.Default.ArrowBack,
                onNavigationClick = onBackClick
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            NoticeCategoryFilter(
                categories = viewModel.categories,
                selectedCategory = selectedCategory,
                onCategorySelected = viewModel::onCategorySelected
            )

            when (uiState) {
                is NoticesUiState.Loading -> LoadingState()
                else -> {
                    val filteredNotices = if (selectedCategory == "All") notices else notices.filter { it.category == selectedCategory }
                    if (filteredNotices.isEmpty()) {
                        EmptyState(message = "No notices in this category.")
                    } else {
                        NoticesList(filteredNotices)
                    }
                }
            }
        }
    }
}

@Composable
fun NoticeCategoryFilter(
    categories: List<String>,
    selectedCategory: String,
    onCategorySelected: (String) -> Unit
) {
    LazyRow(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(categories) { category ->
            FilterChip(
                selected = category == selectedCategory,
                onClick = { onCategorySelected(category) },
                label = { Text(category) }
            )
        }
    }
}

@Composable
fun NoticesList(notices: List<Notice>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(notices) { notice ->
            NoticeItem(notice)
        }
    }
}

@Composable
fun NoticeItem(notice: Notice) {
    val context = LocalContext.current
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                NoticeCategoryBadge(notice.category)
                Text(text = notice.publishedDate, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(text = notice.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = notice.description, style = MaterialTheme.typography.bodyMedium)
            
            if (notice.attachmentUrl != null) {
                Spacer(modifier = Modifier.height(16.dp))
                TextButton(
                    onClick = { 
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(notice.attachmentUrl))
                        context.startActivity(intent)
                    },
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Icon(imageVector = Icons.Default.AttachFile, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "View Attachment")
                }
            }
        }
    }
}

@Composable
fun NoticeCategoryBadge(category: String) {
    val color = when (category.lowercase()) {
        "important" -> Color(0xFFF44336)
        "examination" -> Color(0xFF2196F3)
        "academic" -> Color(0xFF4CAF50)
        else -> MaterialTheme.colorScheme.primary
    }
    Surface(
        color = color.copy(alpha = 0.1f),
        shape = MaterialTheme.shapes.extraSmall
    ) {
        Text(
            text = category,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.Bold
        )
    }
}
