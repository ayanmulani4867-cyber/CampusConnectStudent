package com.campusconnect.student.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName

// --- ATTENDANCE ---

data class AttendanceResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("summary") val summary: AttendanceSummary?,
    @SerializedName("subject_breakdown") val subjectWise: List<SubjectAttendance>?,
    @SerializedName("recent_history") val history: List<AttendanceRecord>?
)

data class AttendanceSummary(
    @SerializedName("overall_percentage") val overallPercentage: Float,
    @SerializedName("total_conducted") val totalConducted: Int,
    @SerializedName("total_attended") val totalAttended: Int,
    @SerializedName("total_absent") val totalAbsent: Int,
    @SerializedName("total_late") val totalLate: Int,
    @SerializedName("minimum_required") val minimumRequired: Float = 75f,
    @SerializedName("is_eligible_for_exams") val isEligible: Boolean,
    @SerializedName("classes_needed_for_75") val classesNeeded: Int
)

@Entity(tableName = "subject_attendance")
data class SubjectAttendance(
    @PrimaryKey @SerializedName("subject_id") val subjectId: Int,
    @SerializedName("subject_code") val subjectCode: String,
    @SerializedName("subject_name") val subjectName: String,
    @SerializedName("attended_classes") val attendedClasses: Int,
    @SerializedName("absent_classes") val absentClasses: Int,
    @SerializedName("total_classes") val totalClasses: Int,
    @SerializedName("percentage") val percentage: Float,
    @SerializedName("is_shortage") val isShortage: Boolean
)

@Entity(tableName = "attendance_history")
data class AttendanceRecord(
    @PrimaryKey @SerializedName("id") val id: Int,
    @SerializedName("date") val date: String,
    @SerializedName("subject_name") val subjectName: String,
    @SerializedName("subject_code") val subjectCode: String?,
    @SerializedName("status") val status: String, // "Present", "Absent", "Late"
    @SerializedName("faculty_name") val facultyName: String?,
    @SerializedName("time_slot") val timeSlot: String?,
    @SerializedName("topic_covered") val topic: String?
)

// --- RESULTS ---

data class ResultsResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("summary") val summary: ResultSummary?,
    @SerializedName("grade_cards") val gradeCards: List<SubjectGrade>?
)

data class ResultSummary(
    @SerializedName("cgpa") val cgpa: Double?,
    @SerializedName("overall_percentage") val overallPercentage: Double?,
    @SerializedName("total_subjects_evaluated") val totalSubjects: Int,
    @SerializedName("passed_count") val passedCount: Int,
    @SerializedName("failed_count") val failedCount: Int
)

@Entity(tableName = "semester_results")
data class SemesterResult(
    @PrimaryKey val semesterId: Int,
    val semesterNo: Int,
    val sgpa: Double,
    val totalCredits: Int,
    val isPublished: Boolean,
    val marksheetUrl: String?,
    val grades: List<SubjectGrade>
)

data class SubjectGrade(
    @SerializedName("id") val id: Int,
    @SerializedName("subject_id") val subjectId: Int,
    @SerializedName("subject_code") val subjectCode: String,
    @SerializedName("subject_name") val subjectName: String,
    @SerializedName("exam_name") val examName: String?,
    @SerializedName("marks_obtained") val marks: Double,
    @SerializedName("max_marks") val maxMarks: Double,
    @SerializedName("percentage") val percentage: Double,
    @SerializedName("grade") val grade: String,
    @SerializedName("grade_point") val gradePoint: Double,
    @SerializedName("is_passed") val isPassed: Boolean,
    @SerializedName("published_at") val publishedAt: String?,
    @SerializedName("remarks") val remarks: String?
)

// --- TIMETABLE ---

data class TimetableResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("timetable_by_day") val timetableByDay: Map<String, List<TimetableEntry>>?,
    @SerializedName("classes") val classesToday: List<TimetableEntry>? // For /today endpoint
)

@Entity(tableName = "timetable")
data class TimetableEntry(
    @PrimaryKey @SerializedName("id") val id: Int,
    var day: String? = null, 
    @SerializedName("start_time") val startTime: String,
    @SerializedName("end_time") val endTime: String,
    @SerializedName("subject_name") val subjectName: String,
    @SerializedName("subject_code") val subjectCode: String?,
    @SerializedName("subject_id") val subjectId: Int?,
    @SerializedName("faculty_id") val facultyId: Int?,
    @SerializedName("faculty_name") val facultyName: String,
    @SerializedName("room_number") val room: String,
    @SerializedName("status") val status: String? // "upcoming", "in_progress", "completed"
)
