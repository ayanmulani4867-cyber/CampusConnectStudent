package com.campusconnect.student.data.model

import com.google.gson.annotations.SerializedName

data class DashboardResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("dashboard") val data: DashboardData?
)

data class DashboardData(
    @SerializedName("student_name") val studentName: String,
    @SerializedName("roll_no") val rollNo: String?,
    @SerializedName("department") val department: String?,
    @SerializedName("course") val course: String?,
    @SerializedName("semester") val semester: Int?,
    @SerializedName("division") val division: String?,
    @SerializedName("attendance") val attendance: DashboardAttendance?,
    @SerializedName("academics") val academics: DashboardAcademics?,
    @SerializedName("fees") val fees: DashboardFees?,
    @SerializedName("pending_assignments_count") val pendingAssignmentsCount: Int,
    @SerializedName("upcoming_assignments") val upcomingAssignments: List<AssignmentSummary>?,
    @SerializedName("today_schedule") val todaySchedule: List<TimetableItem>?,
    @SerializedName("upcoming_exams") val upcomingExams: List<ExamSummary>?,
    @SerializedName("unread_notifications_count") val unreadNotificationsCount: Int,
    @SerializedName("active_notices_count") val activeNoticesCount: Int
)

data class DashboardAttendance(
    @SerializedName("percentage") val percentage: Float,
    @SerializedName("attended_classes") val attended: Int,
    @SerializedName("total_classes") val total: Int,
    @SerializedName("is_eligible") val isEligible: Boolean
)

data class DashboardAcademics(
    @SerializedName("cgpa") val cgpa: Double?,
    @SerializedName("total_exams_graded") val totalExamsGraded: Int,
    @SerializedName("passed_exams") val passedExams: Int
)

data class DashboardFees(
    @SerializedName("total_fees") val total: Double,
    @SerializedName("paid_amount") val paid: Double,
    @SerializedName("pending_amount") val pending: Double,
    @SerializedName("status") val status: String
)

data class TimetableItem(
    @SerializedName("id") val id: Int,
    @SerializedName("start_time") val startTime: String,
    @SerializedName("end_time") val endTime: String,
    @SerializedName("subject_name") val subject: String,
    @SerializedName("subject_code") val subjectCode: String?,
    @SerializedName("faculty_name") val faculty: String,
    @SerializedName("room_number") val room: String
)

data class AssignmentSummary(
    @SerializedName("id") val id: Int,
    @SerializedName("title") val title: String,
    @SerializedName("subject_name") val subject: String,
    @SerializedName("due_date") val deadline: String,
    @SerializedName("max_marks") val maxMarks: Double
)

data class ExamSummary(
    @SerializedName("id") val id: Int,
    @SerializedName("name") val name: String?,
    @SerializedName("subject_name") val subject: String,
    @SerializedName("exam_date") val date: String,
    @SerializedName("start_time") val time: String,
    @SerializedName("room_number") val room: String?
)
