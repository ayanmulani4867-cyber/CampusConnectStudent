package com.campusconnect.student.data.api

import com.campusconnect.student.data.model.*
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST

interface ServicesApi {
    @GET("api/student/fees")
    suspend fun getFees(@Header("Authorization") token: String): Response<FeeResponse>

    @GET("api/student/fees/history")
    suspend fun getFeeHistory(@Header("Authorization") token: String): Response<FeeHistoryResponse>

    @GET("api/student/leaves")
    suspend fun getLeaveHistory(@Header("Authorization") token: String): Response<LeaveHistoryResponse>

    @POST("api/student/leave/apply")
    suspend fun applyLeave(
        @Header("Authorization") token: String,
        @Body request: LeaveApplyRequest
    ): Response<LeaveApplyResponse>

    @POST("api/student/feedback")
    suspend fun submitFeedback(
        @Header("Authorization") token: String,
        @Body request: FeedbackRequest
    ): Response<FeedbackResponse>
}
