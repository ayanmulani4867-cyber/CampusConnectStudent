package com.campusconnect.student

import android.app.Application
import androidx.room.Room
import com.campusconnect.student.data.api.*
import com.campusconnect.student.data.database.AppDatabase
import com.campusconnect.student.data.preferences.SessionManager
import com.campusconnect.student.data.repository.*
import com.campusconnect.student.utils.Constants

class CampusApp : Application() {
    
    companion object {
        lateinit var instance: CampusApp
            private set
    }

    lateinit var database: AppDatabase
        private set

    lateinit var sessionManager: SessionManager
        private set

    lateinit var authRepository: AuthRepository
        private set

    lateinit var studentRepository: StudentRepository
        private set

    lateinit var academicRepository: AcademicRepository
        private set

    lateinit var academicsExtendedRepository: AcademicsExtendedRepository
        private set

    lateinit var servicesRepository: ServicesRepository
        private set

    lateinit var campusRepository: CampusRepository
        private set

    lateinit var communicationRepository: CommunicationRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        
        database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            Constants.DATABASE_NAME
        ).fallbackToDestructiveMigration().build()

        sessionManager = SessionManager(this)
        val retrofitClient = RetrofitClient(sessionManager)
        
        val authApi = retrofitClient.createService<AuthApi>()
        authRepository = AuthRepository(authApi, sessionManager)

        val studentApi = retrofitClient.createService<StudentApi>()
        studentRepository = StudentRepository(studentApi, database.studentDao(), sessionManager)

        val academicApi = retrofitClient.createService<AcademicApi>()
        academicRepository = AcademicRepository(
            academicApi,
            database.attendanceDao(),
            database.resultDao(),
            database.timetableDao(),
            sessionManager
        )

        val academicsExtendedApi = retrofitClient.createService<AcademicsExtendedApi>()
        academicsExtendedRepository = AcademicsExtendedRepository(
            academicsExtendedApi,
            database.assignmentDao(),
            database.studyMaterialDao(),
            database.examDao(),
            sessionManager
        )

        val servicesApi = retrofitClient.createService<ServicesApi>()
        servicesRepository = ServicesRepository(
            servicesApi,
            database.feeDao(),
            database.leaveDao(),
            sessionManager
        )

        val campusApi = retrofitClient.createService<CampusApi>()
        campusRepository = CampusRepository(
            campusApi,
            database.certificateDao(),
            database.complaintDao(),
            database.eventDao(),
            sessionManager
        )

        val communicationApi = retrofitClient.createService<CommunicationApi>()
        communicationRepository = CommunicationRepository(
            communicationApi,
            database.noticeDao(),
            database.notificationDao(),
            sessionManager
        )
    }
}
