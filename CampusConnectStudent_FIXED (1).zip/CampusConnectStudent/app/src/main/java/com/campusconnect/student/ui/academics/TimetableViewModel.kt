package com.campusconnect.student.ui.academics

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.campusconnect.student.data.model.TimetableEntry
import com.campusconnect.student.data.repository.AcademicRepository
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.*

sealed class TimetableUiState {
    object Loading : TimetableUiState()
    object Success : TimetableUiState()
    data class Error(val message: String) : TimetableUiState()
}

class TimetableViewModel(private val repository: AcademicRepository) : ViewModel() {

    private val _uiState = mutableStateOf<TimetableUiState>(TimetableUiState.Loading)
    val uiState: State<TimetableUiState> = _uiState

    private val _timetable = mutableStateOf<List<TimetableEntry>>(emptyList())
    val timetable: State<List<TimetableEntry>> = _timetable

    private val _selectedDay = mutableStateOf(getCurrentDay())
    val selectedDay: State<String> = _selectedDay

    val days = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")

    init {
        observeData()
        refresh()
    }

    private fun getCurrentDay(): String {
        val calendar = Calendar.getInstance()
        val dayNames = arrayOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
        val day = dayNames[calendar.get(Calendar.DAY_OF_WEEK) - 1]
        return if (day == "Sunday") "Monday" else day
    }

    private fun observeData() {
        viewModelScope.launch {
            repository.timetable.collectLatest {
                _timetable.value = it
            }
        }
    }

    fun onDaySelected(day: String) {
        _selectedDay.value = day
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.value = TimetableUiState.Loading
            val result = repository.refreshTimetable()
            result.onSuccess {
                _uiState.value = TimetableUiState.Success
            }.onFailure {
                _uiState.value = TimetableUiState.Error(it.message ?: "Failed to load timetable")
            }
        }
    }
}
