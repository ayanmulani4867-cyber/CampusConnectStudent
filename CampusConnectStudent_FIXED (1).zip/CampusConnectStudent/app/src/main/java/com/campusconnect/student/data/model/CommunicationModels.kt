package com.campusconnect.student.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName

// --- NOTICES ---

@Entity(tableName = "notices")
data class Notice(
    @PrimaryKey @SerializedName("id") val id: Int,
    @SerializedName("title") val title: String,
    @SerializedName("content") val description: String,
    @SerializedName("priority") val priority: String?, 
    @SerializedName("publish_date") val publishedDate: String,
    @SerializedName("published_by") val publishedBy: String?,
    @SerializedName("attachment_url") val attachmentUrl: String?
)

data class NoticeResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("notices") val notices: List<Notice>?
)

// --- NOTIFICATIONS ---

@Entity(tableName = "notifications")
data class AppNotification(
    @PrimaryKey @SerializedName("id") val id: Int,
    @SerializedName("title") val title: String,
    @SerializedName("message") val message: String,
    @SerializedName("notification_type") val type: String,
    @SerializedName("created_at") val timestamp: String,
    @SerializedName("link") val link: String?,
    @SerializedName("is_read") val isRead: Boolean = false
)

data class NotificationResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("notifications") val notifications: List<AppNotification>?,
    @SerializedName("unread_count") val unreadCount: Int
)

data class TokenSyncRequest(
    @SerializedName("token") val fcmToken: String
)

data class MarkReadRequest(
    @SerializedName("notification_id") val notificationId: Int?
)
