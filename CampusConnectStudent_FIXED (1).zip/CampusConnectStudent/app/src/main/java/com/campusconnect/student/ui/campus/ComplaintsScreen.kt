package com.campusconnect.student.ui.campus

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.campusconnect.student.data.model.ComplaintRecord
import com.campusconnect.student.ui.common.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComplaintsScreen(
    viewModel: ComplaintsViewModel,
    onBackClick: () -> Unit
) {
    val uiState by viewModel.uiState
    val complaints by viewModel.complaints
    var showCreateDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            CampusAppBar(
                title = "Complaints",
                navigationIcon = Icons.Default.ArrowBack,
                onNavigationClick = onBackClick
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showCreateDialog = true }) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "New Complaint")
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            if (complaints.isEmpty()) {
                EmptyState(message = "No complaints filed yet.")
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(complaints) { complaint ->
                        ComplaintItem(complaint)
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        CreateComplaintDialog(
            onDismiss = { showCreateDialog = false },
            onSubmit = { category, title, desc ->
                viewModel.createComplaint(category, title, desc)
                showCreateDialog = false
            }
        )
    }

    if (uiState is ComplaintsUiState.Success) {
        viewModel.resetState()
    }
}

@Composable
fun ComplaintItem(complaint: ComplaintRecord) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Ticket: ${complaint.id}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                ComplaintStatusBadge(complaint.status)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = complaint.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(text = complaint.category, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
            Spacer(modifier = Modifier.height(12.dp))
            Text(text = complaint.description, style = MaterialTheme.typography.bodyMedium, maxLines = 3)
            
            if (complaint.resolutionComments != null) {
                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(thickness = 0.5.dp)
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "Resolution: ${complaint.resolutionComments}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF4CAF50))
            }
        }
    }
}

@Composable
fun ComplaintStatusBadge(status: String) {
    val color = when (status.lowercase()) {
        "resolved", "closed" -> Color(0xFF4CAF50)
        "in progress", "assigned" -> Color(0xFF2196F3)
        "submitted" -> Color(0xFFFF9800)
        else -> MaterialTheme.colorScheme.outline
    }
    Surface(
        color = color.copy(alpha = 0.1f),
        shape = MaterialTheme.shapes.extraSmall
    ) {
        Text(
            text = status,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.Bold
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateComplaintDialog(
    onDismiss: () -> Unit,
    onSubmit: (String, String, String) -> Unit
) {
    var category by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Complaint") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
            }
        },
        confirmButton = {
            Button(onClick = { onSubmit(category, title, description) }) {
                Text("Submit")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
