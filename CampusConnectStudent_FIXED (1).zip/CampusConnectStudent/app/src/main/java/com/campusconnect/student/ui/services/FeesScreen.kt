package com.campusconnect.student.ui.services

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.campusconnect.student.data.model.FeeResponse
import com.campusconnect.student.data.model.PaymentRecord
import com.campusconnect.student.ui.common.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FeesScreen(
    viewModel: FeesViewModel,
    onBackClick: () -> Unit
) {
    val uiState by viewModel.uiState
    val history by viewModel.paymentHistory

    Scaffold(
        topBar = {
            CampusAppBar(
                title = "Fees & Payments",
                navigationIcon = Icons.Default.ArrowBack,
                onNavigationClick = onBackClick
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (uiState) {
                is FeesUiState.Loading -> LoadingState()
                is FeesUiState.Success -> {
                    val summary = (uiState as FeesUiState.Success).summary
                    FeesContent(summary, history)
                }
                is FeesUiState.Error -> ErrorState(
                    message = (uiState as FeesUiState.Error).message,
                    onRetry = { viewModel.refresh() }
                )
            }
        }
    }
}

@Composable
fun FeesContent(summary: FeeResponse, history: List<PaymentRecord>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            FeeSummaryCard(summary)
        }
        item {
            Text(
                text = "Payment History",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
        if (history.isEmpty()) {
            item {
                EmptyState(message = "No payment records found.")
            }
        } else {
            items(history) { record ->
                PaymentItem(record)
            }
        }
    }
}

@Composable
fun FeeSummaryCard(summary: FeeResponse) {
    val stats = summary.summary ?: return
    CampusCard {
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(text = "Fee Status: ${if (stats.isFullyPaid) "Fully Paid" else "Pending"}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(16.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                FeeSummaryItem("Total", "₹${stats.totalPayable}", Modifier.weight(1f))
                FeeSummaryItem("Paid", "₹${stats.totalPaid}", Modifier.weight(1f), color = Color(0xFF4CAF50))
                FeeSummaryItem("Pending", "₹${stats.totalPending}", Modifier.weight(1f), color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
fun FeeSummaryItem(label: String, value: String, modifier: Modifier = Modifier, color: Color = Color.Unspecified) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, style = MaterialTheme.typography.labelSmall)
        Text(text = value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = color)
    }
}

@Composable
fun PaymentItem(record: PaymentRecord) {
    val context = LocalContext.current
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.ReceiptLong,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = "₹${record.amount}", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                Text(text = "${record.date} | ${record.paymentType}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (record.receiptUrl != null) {
                IconButton(onClick = {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(record.receiptUrl))
                    context.startActivity(intent)
                }) {
                    Icon(imageVector = Icons.Default.Download, contentDescription = "Download Receipt")
                }
            }
        }
    }
}
