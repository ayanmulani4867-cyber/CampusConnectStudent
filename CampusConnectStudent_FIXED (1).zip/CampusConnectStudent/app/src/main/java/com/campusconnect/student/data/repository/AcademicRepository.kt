package com.campusconnect.student.data.repository

import com.campusconnect.student.data.api.AcademicApi
import com.campusconnect.student.data.database.AttendanceDao
import com.campusconnect.student.data.database.ResultDao
import com.campusconnect.student.data.database.TimetableDao
import com.campusconnect.student.data.model.*
import com.campusconnect.student.data.preferences.SessionManager
import kotlinx.coroutines.flow.Flow
import java.util.*

class AcademicRepository(
    private val academicApi: AcademicApi,
    private val attendanceDao: AttendanceDao,
    private val resultDao: ResultDao,
    private val timetableDao: TimetableDao,
    private val sessionManager: SessionManager
) {
    // Attendance
    val subjectAttendance = attendanceDao.getSubjectAttendance()
    val attendanceHistory = attendanceDao.getAttendanceHistory()

    suspend fun refreshAttendance(): Result<AttendanceResponse> {
        return try {
            val token = sessionManager.getAuthToken() ?: return Result.failure(Exception("Not authenticated"))
            val response = academicApi.getAttendance("Bearer $token")
            if (response.isSuccessful && response.body() != null) {
                val data = response.body()!!
                if (data.success) {
                    data.subjectWise?.let { attendanceDao.insertSubjectAttendance(it) }
                    data.history?.let { attendanceDao.insertAttendanceHistory(it) }
                    Result.success(data)
                } else {
                    Result.failure(Exception("Failed to fetch attendance"))
                }
            } else {
                Result.failure(Exception("Network error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Results
    val results = resultDao.getResults()

    suspend fun refreshResults(): Result<ResultsResponse> {
        return try {
            val token = sessionManager.getAuthToken() ?: return Result.failure(Exception("Not authenticated"))
            val response = academicApi.getResults("Bearer $token")
            if (response.isSuccessful && response.body() != null) {
                val data = response.body()!!
                if (data.success && data.gradeCards != null) {
                    // Create a dummy semester result to satisfy existing UI
                    val dummySemester = SemesterResult(
                        semesterId = 0,
                        semesterNo = 1, // Fallback
                        sgpa = data.summary?.cgpa ?: 0.0,
                        totalCredits = data.summary?.totalSubjects ?: 0,
                        isPublished = true,
                        marksheetUrl = null,
                        grades = data.gradeCards
                    )
                    resultDao.insertResults(listOf(dummySemester))
                    Result.success(data)
                } else {
                    Result.failure(Exception("Failed to fetch results"))
                }
            } else {
                Result.failure(Exception("Network error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Timetable
    val timetable = timetableDao.getTimetable()

    fun getTimetableForToday(): Flow<List<TimetableEntry>> {
        val calendar = Calendar.getInstance()
        val dayNames = arrayOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
        val today = dayNames[calendar.get(Calendar.DAY_OF_WEEK) - 1]
        return timetableDao.getTimetableForDay(today)
    }

    suspend fun refreshTimetable(): Result<TimetableResponse> {
        return try {
            val token = sessionManager.getAuthToken() ?: return Result.failure(Exception("Not authenticated"))
            val response = academicApi.getTimetable("Bearer $token")
            if (response.isSuccessful && response.body() != null) {
                val data = response.body()!!
                if (data.success && data.timetableByDay != null) {
                    val flatList = mutableListOf<TimetableEntry>()
                    data.timetableByDay.forEach { (day, entries) ->
                        entries.forEach { entry ->
                            entry.day = day
                            flatList.add(entry)
                        }
                    }
                    timetableDao.insertTimetable(flatList)
                    Result.success(data)
                } else {
                    Result.failure(Exception("Failed to fetch timetable"))
                }
            } else {
                Result.failure(Exception("Network error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
