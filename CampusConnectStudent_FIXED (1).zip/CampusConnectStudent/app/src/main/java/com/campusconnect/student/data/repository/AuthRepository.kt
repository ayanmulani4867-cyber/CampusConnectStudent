package com.campusconnect.student.data.repository

import com.campusconnect.student.data.api.AuthApi
import com.campusconnect.student.data.model.LoginRequest
import com.campusconnect.student.data.model.LoginResponse
import com.campusconnect.student.data.preferences.SessionManager
import retrofit2.Response

class AuthRepository(
    private val authApi: AuthApi,
    private val sessionManager: SessionManager
) {
    suspend fun login(email: String, password: String): Result<LoginResponse> {
        return try {
            val response = authApi.login(LoginRequest(email, password))
            if (response.isSuccessful && response.body() != null) {
                val loginResponse = response.body()!!
                if (loginResponse.success && loginResponse.token != null) {
                    // Check if role is student from the user payload
                    val role = loginResponse.user?.role?.uppercase()
                    if (role == "STUDENT") {
                        sessionManager.saveAuthToken(loginResponse.token)
                        // Save the student ID for later use
                        loginResponse.student?.studentId?.let { sessionManager.saveStudentId(it) }
                        Result.success(loginResponse)
                    } else {
                        Result.failure(Exception("Access denied. This mobile application is for students only. Please use the Campus Connect Web ERP."))
                    }
                } else {
                    Result.failure(Exception(loginResponse.message ?: "Invalid credentials"))
                }
            } else {
                val errorMsg = when (response.code()) {
                    401 -> "Invalid email or password"
                    403 -> "Account deactivated or access denied"
                    else -> "Network error: ${response.code()}"
                }
                Result.failure(Exception(errorMsg))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun logout() {
        sessionManager.clearSession()
    }

    fun isLoggedIn(): Boolean = sessionManager.isLoggedIn()
}
