package com.campusconnect.student.ui.services

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.campusconnect.student.data.model.LeaveApplication
import com.campusconnect.student.data.model.LeaveApplyRequest
import com.campusconnect.student.data.repository.ServicesRepository
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

sealed class LeaveUiState {
    object Idle : LeaveUiState()
    object Loading : LeaveUiState()
    object Success : LeaveUiState()
    data class Error(val message: String) : LeaveUiState()
}

class LeaveViewModel(private val repository: ServicesRepository) : ViewModel() {

    private val _uiState = mutableStateOf<LeaveUiState>(LeaveUiState.Idle)
    val uiState: State<LeaveUiState> = _uiState

    private val _leaveHistory = mutableStateOf<List<LeaveApplication>>(emptyList())
    val leaveHistory: State<List<LeaveApplication>> = _leaveHistory

    init {
        observeData()
        refreshHistory()
    }

    private fun observeData() {
        viewModelScope.launch {
            repository.leaveHistory.collectLatest {
                _leaveHistory.value = it
            }
        }
    }

    fun refreshHistory() {
        viewModelScope.launch {
            repository.refreshLeaveHistory()
        }
    }

    fun applyLeave(leaveType: String, startDate: String, endDate: String, reason: String) {
        if (leaveType.isBlank() || startDate.isBlank() || endDate.isBlank() || reason.isBlank()) {
            _uiState.value = LeaveUiState.Error("Please fill all fields")
            return
        }

        viewModelScope.launch {
            _uiState.value = LeaveUiState.Loading
            val result = repository.applyLeave(LeaveApplyRequest(leaveType, startDate, endDate, reason))
            result.onSuccess {
                _uiState.value = LeaveUiState.Success
            }.onFailure {
                _uiState.value = LeaveUiState.Error(it.message ?: "Failed to apply for leave")
            }
        }
    }

    fun resetState() {
        _uiState.value = LeaveUiState.Idle
    }
}
