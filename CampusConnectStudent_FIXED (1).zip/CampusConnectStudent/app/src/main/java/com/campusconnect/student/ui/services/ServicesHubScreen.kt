package com.campusconnect.student.ui.services

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.campusconnect.student.navigation.Screen
import com.campusconnect.student.ui.common.CampusAppBar

data class ServiceFeature(
    val title: String,
    val icon: ImageVector,
    val route: String
)

val serviceFeatures = listOf(
    ServiceFeature("Fees", Icons.Default.Payments, Screen.Fees.route),
    ServiceFeature("Leave", Icons.Default.EventBusy, Screen.Leave.route),
    ServiceFeature("Feedback", Icons.Default.Feedback, Screen.Feedback.route),
    ServiceFeature("Certificates", Icons.Default.CardMembership, Screen.Certificates.route),
    ServiceFeature("Complaints", Icons.Default.ReportProblem, Screen.Complaints.route)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServicesHubScreen(
    onFeatureClick: (String) -> Unit
) {
    Scaffold(
        topBar = {
            CampusAppBar(title = "Services")
        }
    ) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(serviceFeatures) { feature ->
                ServiceCard(feature, onFeatureClick)
            }
        }
    }
}

@Composable
fun ServiceCard(feature: ServiceFeature, onClick: (String) -> Unit) {
    ElevatedCard(
        onClick = { onClick(feature.route) },
        modifier = Modifier.fillMaxWidth().height(140.dp),
        shape = MaterialTheme.shapes.large
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = feature.icon,
                contentDescription = null,
                modifier = Modifier.size(40.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = feature.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
