package com.campusconnect.student.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName

data class ExamResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("upcoming_exams") val upcomingExams: List<ExamSchedule>?,
    @SerializedName("past_exams") val pastExams: List<ExamSchedule>?
)

@Entity(tableName = "exams")
data class ExamSchedule(
    @PrimaryKey @SerializedName("id") val id: Int,
    @SerializedName("name") val name: String?,
    @SerializedName("exam_type") val examType: String,
    @SerializedName("subject_name") val subjectName: String,
    @SerializedName("subject_code") val subjectCode: String?,
    @SerializedName("exam_date") val date: String,
    @SerializedName("start_time") val startTime: String,
    @SerializedName("end_time") val endTime: String?,
    @SerializedName("room_number") val room: String,
    @SerializedName("max_marks") val maxMarks: Double?,
    @SerializedName("passing_marks") val passingMarks: Double?,
    @SerializedName("is_completed") var isCompleted: Boolean = false
)
