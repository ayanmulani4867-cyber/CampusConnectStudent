package com.campusconnect.student.ui.home

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.campusconnect.student.data.model.DashboardResponse
import com.campusconnect.student.data.model.StudentUser
import com.campusconnect.student.data.repository.CommunicationRepository
import com.campusconnect.student.data.repository.StudentRepository
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

sealed class DashboardUiState {
    object Loading : DashboardUiState()
    data class Success(val data: DashboardResponse) : DashboardUiState()
    data class Error(val message: String) : DashboardUiState()
    object Empty : DashboardUiState()
}

class DashboardViewModel(
    private val studentRepository: StudentRepository,
    private val communicationRepository: CommunicationRepository
) : ViewModel() {

    private val _uiState = mutableStateOf<DashboardUiState>(DashboardUiState.Loading)
    val uiState: State<DashboardUiState> = _uiState

    private val _studentProfile = mutableStateOf<StudentUser?>(null)
    val studentProfile: State<StudentUser?> = _studentProfile

    init {
        observeProfile()
        refreshDashboard()
        syncFcmToken()
    }

    private fun syncFcmToken() {
        try {
            FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val token = task.result
                    viewModelScope.launch {
                        communicationRepository.syncFcmToken(token)
                    }
                }
            }
        } catch (e: Exception) {
            // Firebase not initialized or missing config
        }
    }

    private fun observeProfile() {
        viewModelScope.launch {
            studentRepository.studentProfile.collectLatest { profile ->
                _studentProfile.value = profile
            }
        }
    }

    fun refreshDashboard() {
        viewModelScope.launch {
            _uiState.value = DashboardUiState.Loading
            
            // Refresh profile in background
            studentRepository.refreshProfile()
            
            val result = studentRepository.getDashboard()
            result.onSuccess { response ->
                if (response.success && response.stats != null) {
                    _uiState.value = DashboardUiState.Success(response)
                } else {
                    _uiState.value = DashboardUiState.Empty
                }
            }.onFailure {
                _uiState.value = DashboardUiState.Error(it.message ?: "Failed to load dashboard")
            }
        }
    }
}
