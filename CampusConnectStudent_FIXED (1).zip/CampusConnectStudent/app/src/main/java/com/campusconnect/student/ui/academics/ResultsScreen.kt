package com.campusconnect.student.ui.academics

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.campusconnect.student.data.model.SemesterResult
import com.campusconnect.student.data.model.SubjectGrade
import com.campusconnect.student.ui.common.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultsScreen(
    viewModel: ResultsViewModel,
    onBackClick: () -> Unit
) {
    val uiState by viewModel.uiState
    val results by viewModel.results
    val selectedSemester by viewModel.selectedSemester
    val context = LocalContext.current

    Scaffold(
        topBar = {
            CampusAppBar(
                title = "Results",
                navigationIcon = Icons.Default.ArrowBack,
                onNavigationClick = onBackClick,
                actions = {
                    if (selectedSemester?.marksheetUrl != null) {
                        IconButton(onClick = {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(selectedSemester!!.marksheetUrl))
                            context.startActivity(intent)
                        }) {
                            Icon(imageVector = Icons.Default.FileDownload, contentDescription = "Download Marksheet")
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            if (results.isNotEmpty()) {
                SemesterSelector(
                    semesters = results,
                    selectedSemester = selectedSemester,
                    onSemesterSelected = viewModel::onSemesterSelected
                )
            }

            when (uiState) {
                is ResultsUiState.Loading -> LoadingState()
                else -> {
                    if (selectedSemester != null) {
                        ResultContent(selectedSemester!!)
                    } else {
                        EmptyState(message = "No results published yet.")
                    }
                }
            }
        }
    }
}

@Composable
fun SemesterSelector(
    semesters: List<SemesterResult>,
    selectedSemester: SemesterResult?,
    onSemesterSelected: (SemesterResult) -> Unit
) {
    ScrollableTabRow(
        selectedTabIndex = semesters.indexOf(selectedSemester).coerceAtLeast(0),
        edgePadding = 16.dp,
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.primary,
        divider = {}
    ) {
        semesters.forEach { semester ->
            Tab(
                selected = semester == selectedSemester,
                onClick = { onSemesterSelected(semester) },
                text = { Text("Semester ${semester.semesterNo}") }
            )
        }
    }
}

@Composable
fun ResultContent(result: SemesterResult) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            GpaCard(result)
        }
        item {
            Text(
                text = "Subject Grades",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
        items(result.grades) { grade ->
            GradeItem(grade)
        }
    }
}

@Composable
fun GpaCard(result: SemesterResult) {
    CampusCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = "Semester ${result.semesterNo}", style = MaterialTheme.typography.labelLarge)
                Text(
                    text = "SGPA: ${result.sgpa}",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = MaterialTheme.shapes.medium
            ) {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "Credits", style = MaterialTheme.typography.labelSmall)
                    Text(text = result.totalCredits.toString(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun GradeItem(grade: SubjectGrade) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = grade.subjectName,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = grade.subjectCode,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            
            Column(horizontalAlignment = Alignment.End) {
                Surface(
                    color = getGradeColor(grade.grade).copy(alpha = 0.1f),
                    shape = MaterialTheme.shapes.extraSmall
                ) {
                    Text(
                        text = grade.grade,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = getGradeColor(grade.grade)
                    )
                }
                Text(
                    text = "GP: ${grade.gradePoint}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

fun getGradeColor(grade: String): Color {
    return when (grade.uppercase()) {
        "O", "A+", "A" -> Color(0xFF4CAF50)
        "B+", "B" -> Color(0xFF2196F3)
        "C" -> Color(0xFFFF9800)
        "F" -> Color(0xFFF44336)
        else -> Color(0xFF9E9E9E)
    }
}
