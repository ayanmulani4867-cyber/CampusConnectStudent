package com.campusconnect.student.data.database

import androidx.room.TypeConverter
import com.campusconnect.student.data.model.SubjectGrade
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class Converters {
    @TypeConverter
    fun fromSubjectGradeList(value: List<SubjectGrade>?): String? {
        val gson = Gson()
        val type = object : TypeToken<List<SubjectGrade>>() {}.type
        return gson.toJson(value, type)
    }

    @TypeConverter
    fun toSubjectGradeList(value: String?): List<SubjectGrade>? {
        val gson = Gson()
        val type = object : TypeToken<List<SubjectGrade>>() {}.type
        return gson.fromJson(value, type)
    }
}
