package com.campusconnect.student.data.database

import androidx.room.*
import com.campusconnect.student.data.model.CampusEvent
import com.campusconnect.student.data.model.CertificateRecord
import com.campusconnect.student.data.model.ComplaintRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface CertificateDao {
    @Query("SELECT * FROM certificates ORDER BY requestedOn DESC")
    fun getCertificates(): Flow<List<CertificateRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCertificates(list: List<CertificateRecord>)

    @Query("DELETE FROM certificates")
    suspend fun clearCertificates()
}

@Dao
interface ComplaintDao {
    @Query("SELECT * FROM complaints ORDER BY createdAt DESC")
    fun getComplaints(): Flow<List<ComplaintRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComplaints(list: List<ComplaintRecord>)

    @Query("DELETE FROM complaints")
    suspend fun clearComplaints()
}

@Dao
interface EventDao {
    @Query("SELECT * FROM campus_events ORDER BY startDateTime ASC")
    fun getEvents(): Flow<List<CampusEvent>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvents(list: List<CampusEvent>)

    @Query("DELETE FROM campus_events")
    suspend fun clearEvents()
}
