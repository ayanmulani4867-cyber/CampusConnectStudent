package com.campusconnect.student.ui.services

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.campusconnect.student.data.model.FeeResponse
import com.campusconnect.student.data.model.PaymentRecord
import com.campusconnect.student.data.repository.ServicesRepository
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

sealed class FeesUiState {
    object Loading : FeesUiState()
    data class Success(val summary: FeeResponse) : FeesUiState()
    data class Error(val message: String) : FeesUiState()
}

class FeesViewModel(private val repository: ServicesRepository) : ViewModel() {

    private val _uiState = mutableStateOf<FeesUiState>(FeesUiState.Loading)
    val uiState: State<FeesUiState> = _uiState

    private val _paymentHistory = mutableStateOf<List<PaymentRecord>>(emptyList())
    val paymentHistory: State<List<PaymentRecord>> = _paymentHistory

    init {
        observeData()
        refresh()
    }

    private fun observeData() {
        viewModelScope.launch {
            repository.paymentHistory.collectLatest {
                _paymentHistory.value = it
            }
        }
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.value = FeesUiState.Loading
            val result = repository.refreshFees()
            result.onSuccess {
                _uiState.value = FeesUiState.Success(it)
            }.onFailure {
                _uiState.value = FeesUiState.Error(it.message ?: "Failed to load fees")
            }
        }
    }
}
