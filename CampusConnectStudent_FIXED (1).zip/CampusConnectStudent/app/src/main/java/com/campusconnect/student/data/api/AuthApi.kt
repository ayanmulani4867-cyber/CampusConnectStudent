package com.campusconnect.student.data.api

import com.campusconnect.student.data.model.*
import com.google.gson.annotations.SerializedName
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

interface AuthApi {
    @POST("api/login")
    suspend fun login(@Body request: LoginRequest): Response<LoginResponse>

    @POST("api/auth/change-password")
    suspend fun changePassword(
        @Header("Authorization") token: String,
        @Body request: ChangePasswordRequest
    ): Response<BaseResponse>
}

data class ChangePasswordRequest(
    @SerializedName("current_password") val current: String,
    @SerializedName("new_password") val new: String
)
