package com.campusconnect.student.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.campusconnect.student.CampusApp
import com.campusconnect.student.ui.academics.*
import com.campusconnect.student.ui.auth.LoginScreen
import com.campusconnect.student.ui.auth.LoginViewModel
import com.campusconnect.student.ui.auth.LoginViewModelFactory
import com.campusconnect.student.ui.home.DashboardScreen
import com.campusconnect.student.ui.home.DashboardViewModel
import com.campusconnect.student.ui.home.DashboardViewModelFactory
import com.campusconnect.student.ui.profile.ProfileScreen
import com.campusconnect.student.ui.profile.ProfileViewModel
import com.campusconnect.student.ui.profile.ProfileViewModelFactory
import com.campusconnect.student.ui.services.*
import com.campusconnect.student.ui.campus.*

@Composable
fun AppNavGraph(
    navController: NavHostController,
    modifier: Modifier = Modifier,
    startDestination: String = if (CampusApp.instance.authRepository.isLoggedIn()) Screen.Home.route else Screen.Login.route
) {
    val context = LocalContext.current
    val app = context.applicationContext as CampusApp
    
    NavHost(
        navController = navController,
        startDestination = startDestination,
        modifier = modifier
    ) {
        // Auth
        composable(Screen.Login.route) {
            val viewModel: LoginViewModel = viewModel(
                factory = LoginViewModelFactory(app.authRepository)
            )
            LoginScreen(
                viewModel = viewModel,
                onLoginSuccess = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                }
            )
        }
        composable(Screen.ForgotPassword.route) { PlaceholderScreen("Forgot Password Screen") }
        
        // Main Bottom Nav Screens
        composable(Screen.Home.route) {
            val viewModel: DashboardViewModel = viewModel(
                factory = DashboardViewModelFactory(app.studentRepository, app.communicationRepository)
            )
            DashboardScreen(
                viewModel = viewModel,
                onNotificationClick = { navController.navigate(Screen.Notifications.route) },
                onProfileClick = { navController.navigate(Screen.Profile.route) }
            )
        }
        
        composable(Screen.Academics.route) {
            AcademicsHubScreen(
                onFeatureClick = { route -> navController.navigate(route) }
            )
        }

        composable(Screen.Services.route) {
            ServicesHubScreen(
                onFeatureClick = { route -> navController.navigate(route) }
            )
        }

        composable(Screen.Campus.route) {
            CampusHubScreen(
                onFeatureClick = { route -> navController.navigate(route) }
            )
        }
        
        composable(Screen.Profile.route) {
            val viewModel: ProfileViewModel = viewModel(
                factory = ProfileViewModelFactory(app.studentRepository)
            )
            ProfileScreen(
                viewModel = viewModel,
                onLogout = {
                    app.authRepository.logout()
                    navController.navigate(Screen.Login.route) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }

        // Academics Details
        composable(Screen.Attendance.route) {
            val viewModel: AttendanceViewModel = viewModel(
                factory = AttendanceViewModelFactory(app.academicRepository)
            )
            AttendanceScreen(viewModel = viewModel, onBackClick = { navController.popBackStack() })
        }
        composable(Screen.Results.route) {
            val viewModel: ResultsViewModel = viewModel(
                factory = ResultsViewModelFactory(app.academicRepository)
            )
            ResultsScreen(viewModel = viewModel, onBackClick = { navController.popBackStack() })
        }
        composable(Screen.Timetable.route) {
            val viewModel: TimetableViewModel = viewModel(
                factory = TimetableViewModelFactory(app.academicRepository)
            )
            TimetableScreen(viewModel = viewModel, onBackClick = { navController.popBackStack() })
        }
        composable(Screen.Assignments.route) {
            val viewModel: AssignmentsViewModel = viewModel(
                factory = AssignmentsViewModelFactory(app.academicsExtendedRepository)
            )
            AssignmentsScreen(viewModel = viewModel, onBackClick = { navController.popBackStack() })
        }
        composable(Screen.StudyMaterials.route) {
            val viewModel: StudyMaterialsViewModel = viewModel(
                factory = StudyMaterialsViewModelFactory(app.academicsExtendedRepository)
            )
            StudyMaterialsScreen(viewModel = viewModel, onBackClick = { navController.popBackStack() })
        }
        composable(Screen.Exams.route) {
            val viewModel: ExamsViewModel = viewModel(
                factory = ExamsViewModelFactory(app.academicsExtendedRepository)
            )
            ExamsScreen(viewModel = viewModel, onBackClick = { navController.popBackStack() })
        }

        // Services Details
        composable(Screen.Fees.route) {
            val viewModel: FeesViewModel = viewModel(
                factory = FeesViewModelFactory(app.servicesRepository)
            )
            FeesScreen(viewModel = viewModel, onBackClick = { navController.popBackStack() })
        }
        composable(Screen.Leave.route) {
            val viewModel: LeaveViewModel = viewModel(
                factory = LeaveViewModelFactory(app.servicesRepository)
            )
            LeaveScreen(viewModel = viewModel, onBackClick = { navController.popBackStack() })
        }
        composable(Screen.Feedback.route) {
            val viewModel: FeedbackViewModel = viewModel(
                factory = FeedbackViewModelFactory(app.servicesRepository)
            )
            FeedbackScreen(viewModel = viewModel, onBackClick = { navController.popBackStack() })
        }
        composable(Screen.Certificates.route) {
            val viewModel: CertificatesViewModel = viewModel(
                factory = CertificatesViewModelFactory(app.campusRepository)
            )
            CertificatesScreen(viewModel = viewModel, onBackClick = { navController.popBackStack() })
        }
        composable(Screen.Complaints.route) {
            val viewModel: ComplaintsViewModel = viewModel(
                factory = ComplaintsViewModelFactory(app.campusRepository)
            )
            ComplaintsScreen(viewModel = viewModel, onBackClick = { navController.popBackStack() })
        }

        // Campus Details
        composable(Screen.Notices.route) {
            val viewModel: NoticesViewModel = viewModel(
                factory = NoticesViewModelFactory(app.communicationRepository)
            )
            NoticesScreen(viewModel = viewModel, onBackClick = { navController.popBackStack() })
        }
        composable(Screen.Events.route) {
            val viewModel: EventsViewModel = viewModel(
                factory = EventsViewModelFactory(app.campusRepository)
            )
            EventsScreen(viewModel = viewModel, onBackClick = { navController.popBackStack() })
        }
        composable(Screen.Notifications.route) {
            val viewModel: NotificationsViewModel = viewModel(
                factory = NotificationsViewModelFactory(app.communicationRepository)
            )
            NotificationsScreen(viewModel = viewModel, onBackClick = { navController.popBackStack() })
        }
    }
}

@Composable
fun PlaceholderScreen(name: String) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Text(text = "$name Placeholder\n(To be implemented in later phases)")
    }
}
