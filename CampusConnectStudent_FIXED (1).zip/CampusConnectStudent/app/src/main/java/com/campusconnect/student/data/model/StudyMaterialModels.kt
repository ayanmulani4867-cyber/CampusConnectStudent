package com.campusconnect.student.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName

data class StudyMaterialResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("materials") val materials: List<StudyMaterial>?
)

@Entity(tableName = "study_materials")
data class StudyMaterial(
    @PrimaryKey @SerializedName("id") val id: Int,
    @SerializedName("title") val title: String,
    @SerializedName("description") val description: String?,
    @SerializedName("subject_name") val subjectName: String,
    @SerializedName("subject_code") val subjectCode: String?,
    @SerializedName("faculty_name") val facultyName: String,
    @SerializedName("upload_date") val uploadDate: String,
    @SerializedName("file_type") val fileType: String,
    @SerializedName("file_size_kb") val fileSizeKb: Double?,
    @SerializedName("file_path") val fileUrl: String
)
