package com.campusconnect.student.ui.services

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.campusconnect.student.ui.common.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FeedbackScreen(
    viewModel: FeedbackViewModel,
    onBackClick: () -> Unit
) {
    val uiState by viewModel.uiState
    
    var feedbackType by remember { mutableStateOf("General") }
    var rating by remember { mutableIntStateOf(5) }
    var comments by remember { mutableStateOf("") }

    val types = listOf("General", "Faculty", "Course")

    Scaffold(
        topBar = {
            CampusAppBar(
                title = "Feedback",
                navigationIcon = Icons.Default.ArrowBack,
                onNavigationClick = onBackClick
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Text(text = "We value your feedback!", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            }
            
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(text = "Feedback Type", style = MaterialTheme.typography.labelLarge)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        types.forEach { type ->
                            FilterChip(
                                selected = feedbackType == type,
                                onClick = { feedbackType = type },
                                label = { Text(type) }
                            )
                        }
                    }
                }
            }

            item {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "Rating", style = MaterialTheme.typography.labelLarge)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row {
                        repeat(5) { index ->
                            val starIndex = index + 1
                            IconButton(onClick = { rating = starIndex }) {
                                Icon(
                                    imageVector = if (starIndex <= rating) Icons.Default.Star else Icons.Outlined.StarOutline,
                                    contentDescription = null,
                                    tint = if (starIndex <= rating) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                )
                            }
                        }
                    }
                }
            }

            item {
                OutlinedTextField(
                    value = comments,
                    onValueChange = { comments = it },
                    label = { Text("Your Comments") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 5,
                    placeholder = { Text("Tell us what's on your mind...") }
                )
            }

            item {
                if (uiState is FeedbackUiState.Error) {
                    Text(text = (uiState as FeedbackUiState.Error).message, color = MaterialTheme.colorScheme.error)
                }
            }

            item {
                Button(
                    onClick = { viewModel.submitFeedback(feedbackType, rating, comments) },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    enabled = uiState !is FeedbackUiState.Loading
                ) {
                    if (uiState is FeedbackUiState.Loading) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
                    } else {
                        Text("Submit Feedback")
                    }
                }
            }
        }
    }

    if (uiState is FeedbackUiState.Success) {
        AlertDialog(
            onDismissRequest = { viewModel.resetState() },
            title = { Text("Thank You!") },
            text = { Text("Your feedback has been submitted successfully.") },
            confirmButton = {
                TextButton(onClick = { 
                    viewModel.resetState()
                    onBackClick()
                }) {
                    Text("OK")
                }
            }
        )
    }
}
