package com.campusconnect.student.ui.campus

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.campusconnect.student.data.repository.CampusRepository

class CertificatesViewModelFactory(private val repository: CampusRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(CertificatesViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return CertificatesViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

class ComplaintsViewModelFactory(private val repository: CampusRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ComplaintsViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ComplaintsViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

class EventsViewModelFactory(private val repository: CampusRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(EventsViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return EventsViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
