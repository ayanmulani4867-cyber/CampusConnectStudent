package com.campusconnect.student.ui.academics

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.campusconnect.student.data.model.TimetableEntry
import com.campusconnect.student.ui.common.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimetableScreen(
    viewModel: TimetableViewModel,
    onBackClick: () -> Unit
) {
    val uiState by viewModel.uiState
    val timetable by viewModel.timetable
    val selectedDay by viewModel.selectedDay

    Scaffold(
        topBar = {
            CampusAppBar(
                title = "Timetable",
                navigationIcon = Icons.Default.ArrowBack,
                onNavigationClick = onBackClick
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            DaySelector(
                days = viewModel.days,
                selectedDay = selectedDay,
                onDaySelected = viewModel::onDaySelected
            )

            when (uiState) {
                is TimetableUiState.Loading -> LoadingState()
                else -> {
                    val filteredTimetable = timetable.filter { it.day == selectedDay }
                    if (filteredTimetable.isNotEmpty()) {
                        TimetableContent(filteredTimetable)
                    } else {
                        EmptyState(message = "No classes scheduled for $selectedDay")
                    }
                }
            }
        }
    }
}

@Composable
fun DaySelector(
    days: List<String>,
    selectedDay: String,
    onDaySelected: (String) -> Unit
) {
    ScrollableTabRow(
        selectedTabIndex = days.indexOf(selectedDay).coerceAtLeast(0),
        edgePadding = 16.dp,
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.primary,
        divider = {}
    ) {
        days.forEach { day ->
            Tab(
                selected = day == selectedDay,
                onClick = { onDaySelected(day) },
                text = { Text(day.take(3)) }
            )
        }
    }
}

@Composable
fun TimetableContent(timetable: List<TimetableEntry>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(timetable) { entry ->
            TimetableItem(entry)
        }
    }
}

@Composable
fun TimetableItem(entry: TimetableEntry) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            modifier = Modifier.width(80.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = entry.time.split("-").firstOrNull() ?: "",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = entry.time.split("-").lastOrNull() ?: "",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(modifier = Modifier.width(16.dp))

        Box(
            modifier = Modifier
                .width(2.dp)
                .height(80.dp)
                .background(MaterialTheme.colorScheme.primaryContainer)
        )

        Spacer(modifier = Modifier.width(16.dp))

        ElevatedCard(
            modifier = Modifier.weight(1f),
            shape = MaterialTheme.shapes.medium
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = entry.subjectName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Schedule,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${entry.room} | ${entry.facultyName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
