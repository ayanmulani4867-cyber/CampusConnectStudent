package com.campusconnect.student.ui.academics

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.campusconnect.student.data.model.StudyMaterial
import com.campusconnect.student.ui.common.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyMaterialsScreen(
    viewModel: StudyMaterialsViewModel,
    onBackClick: () -> Unit
) {
    val uiState by viewModel.uiState
    val materials by viewModel.studyMaterials
    val context = LocalContext.current

    Scaffold(
        topBar = {
            CampusAppBar(
                title = "Study Materials",
                navigationIcon = Icons.Default.ArrowBack,
                onNavigationClick = onBackClick
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (uiState) {
                is StudyMaterialsUiState.Loading -> LoadingState()
                else -> {
                    if (materials.isEmpty()) {
                        EmptyState(message = "No study materials uploaded yet.")
                    } else {
                        StudyMaterialsList(
                            materials = materials,
                            onDownloadClick = { material ->
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(material.fileUrl))
                                context.startActivity(intent)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StudyMaterialsList(
    materials: List<StudyMaterial>,
    onDownloadClick: (StudyMaterial) -> Unit
) {
    val grouped = materials.groupBy { it.subjectName }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        grouped.forEach { (subject, items) ->
            item {
                Text(
                    text = subject,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            items(items) { material ->
                MaterialItem(material, onDownloadClick)
            }
        }
    }
}

@Composable
fun MaterialItem(
    material: StudyMaterial,
    onDownloadClick: (StudyMaterial) -> Unit
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = when (material.fileType.uppercase()) {
                    "PDF" -> Icons.Default.PictureAsPdf
                    "PPT" -> Icons.Default.Slideshow
                    else -> Icons.Default.Description
                },
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp)
            )
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = material.title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "By ${material.facultyName} | ${material.uploadDate}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            
            IconButton(onClick = { onDownloadClick(material) }) {
                Icon(imageVector = Icons.Default.Download, contentDescription = "Download")
            }
        }
    }
}
