package com.campusconnect.student.ui.campus

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.campusconnect.student.data.repository.CommunicationRepository

class NoticesViewModelFactory(private val repository: CommunicationRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(NoticesViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return NoticesViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

class NotificationsViewModelFactory(private val repository: CommunicationRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(NotificationsViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return NotificationsViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
