package com.campusconnect.student.data.repository

import com.campusconnect.student.data.api.AcademicsExtendedApi
import com.campusconnect.student.data.database.AssignmentDao
import com.campusconnect.student.data.database.ExamDao
import com.campusconnect.student.data.database.StudyMaterialDao
import com.campusconnect.student.data.model.*
import com.campusconnect.student.data.preferences.SessionManager
import kotlinx.coroutines.flow.Flow
import okhttp3.MultipartBody
import okhttp3.RequestBody

class AcademicsExtendedRepository(
    private val api: AcademicsExtendedApi,
    private val assignmentDao: AssignmentDao,
    private val studyMaterialDao: StudyMaterialDao,
    private val examDao: ExamDao,
    private val sessionManager: SessionManager
) {
    // Assignments
    val assignments: Flow<List<Assignment>> = assignmentDao.getAssignments()

    suspend fun refreshAssignments(): Result<List<Assignment>> {
        return try {
            val token = sessionManager.getAuthToken() ?: return Result.failure(Exception("Not authenticated"))
            val response = api.getAssignments("Bearer $token")
            if (response.isSuccessful && response.body() != null) {
                val data = response.body()!!
                if (data.success && data.assignments != null) {
                    assignmentDao.insertAssignments(data.assignments)
                    Result.success(data.assignments)
                } else {
                    Result.failure(Exception("Failed to fetch assignments"))
                }
            } else {
                Result.failure(Exception("Network error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun submitAssignment(assignmentId: String, filePart: MultipartBody.Part): Result<String> {
        return try {
            val token = sessionManager.getAuthToken() ?: return Result.failure(Exception("Not authenticated"))
            val response = api.submitAssignment(token = "Bearer $token", assignmentId = assignmentId, submission_file = filePart)
            if (response.isSuccessful && response.body() != null) {
                val data = response.body()!!
                if (data.success) {
                    refreshAssignments()
                    Result.success(data.message ?: "Submitted")
                } else {
                    Result.failure(Exception(data.message ?: "Failed to submit assignment"))
                }
            } else {
                Result.failure(Exception("Network error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Study Materials
    val studyMaterials: Flow<List<StudyMaterial>> = studyMaterialDao.getStudyMaterials()

    suspend fun refreshStudyMaterials(): Result<List<StudyMaterial>> {
        return try {
            val token = sessionManager.getAuthToken() ?: return Result.failure(Exception("Not authenticated"))
            val response = api.getStudyMaterials("Bearer $token")
            if (response.isSuccessful && response.body() != null) {
                val data = response.body()!!
                if (data.success && data.materials != null) {
                    studyMaterialDao.insertStudyMaterials(data.materials)
                    Result.success(data.materials)
                } else {
                    Result.failure(Exception("Failed to fetch study materials"))
                }
            } else {
                Result.failure(Exception("Network error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Exams
    val exams: Flow<List<ExamSchedule>> = examDao.getExams()

    suspend fun refreshExams(): Result<List<ExamSchedule>> {
        return try {
            val token = sessionManager.getAuthToken() ?: return Result.failure(Exception("Not authenticated"))
            val response = api.getExams("Bearer $token")
            if (response.isSuccessful && response.body() != null) {
                val data = response.body()!!
                if (data.success) {
                    val allExams = mutableListOf<ExamSchedule>()
                    data.upcomingExams?.forEach { 
                        it.isCompleted = false
                        allExams.add(it) 
                    }
                    data.pastExams?.forEach { 
                        it.isCompleted = true
                        allExams.add(it) 
                    }
                    examDao.insertExams(allExams)
                    Result.success(allExams)
                } else {
                    Result.failure(Exception("Failed to fetch exams"))
                }
            } else {
                Result.failure(Exception("Network error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
