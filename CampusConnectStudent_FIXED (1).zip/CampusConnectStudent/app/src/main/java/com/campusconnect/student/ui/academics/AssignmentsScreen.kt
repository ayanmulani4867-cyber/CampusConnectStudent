package com.campusconnect.student.ui.academics

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.campusconnect.student.data.model.Assignment
import com.campusconnect.student.ui.common.*
import com.campusconnect.student.utils.ImageUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssignmentsScreen(
    viewModel: AssignmentsViewModel,
    onBackClick: () -> Unit
) {
    val uiState by viewModel.uiState
    val assignments by viewModel.assignments
    val context = LocalContext.current

    var selectedAssignmentForUpload by remember { mutableStateOf<Assignment?>(null) }
    
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            val part = ImageUtils.prepareImagePart(context, "file", it) // Reusing ImageUtils for part prep
            if (part != null && selectedAssignmentForUpload != null) {
                viewModel.submitAssignment(selectedAssignmentForUpload!!.id, part)
            }
        }
    }

    Scaffold(
        topBar = {
            CampusAppBar(
                title = "Assignments",
                navigationIcon = Icons.Default.ArrowBack,
                onNavigationClick = onBackClick
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (uiState) {
                is AssignmentsUiState.Loading -> LoadingState()
                else -> {
                    if (assignments.isEmpty()) {
                        EmptyState(message = "No assignments assigned yet.")
                    } else {
                        AssignmentsList(
                            assignments = assignments,
                            onUploadClick = { 
                                selectedAssignmentForUpload = it
                                filePickerLauncher.launch("*/*")
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AssignmentsList(
    assignments: List<Assignment>,
    onUploadClick: (Assignment) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(assignments) { assignment ->
            AssignmentItem(assignment, onUploadClick)
        }
    }
}

@Composable
fun AssignmentItem(
    assignment: Assignment,
    onUploadClick: (Assignment) -> Unit
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Assignment,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = assignment.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = assignment.subjectName,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                val status = assignment.submission?.status ?: "Pending"
                StatusBadge(status)
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Text(
                text = assignment.description ?: "No description provided.",
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 2
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column {
                    Text(text = "Deadline", style = MaterialTheme.typography.labelSmall)
                    Text(text = assignment.deadline, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                }
                
                val isSubmitted = assignment.submission?.isSubmitted ?: false
                if (!isSubmitted) {
                    Button(
                        onClick = { onUploadClick(assignment) },
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.FileUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "Submit")
                    }
                } else if (assignment.submission?.status == "Graded") {
                    Text(
                        text = "Score: ${assignment.submission.obtainedMarks}/${assignment.maxMarks}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                } else {
                    Text(
                        text = "Submitted",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF4CAF50),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun StatusBadge(status: String) {
    val color = when (status) {
        "Submitted" -> Color(0xFF4CAF50)
        "Evaluated" -> Color(0xFF2196F3)
        "Late" -> Color(0xFFF44336)
        else -> MaterialTheme.colorScheme.outline
    }
    Surface(
        color = color.copy(alpha = 0.1f),
        shape = MaterialTheme.shapes.extraSmall
    ) {
        Text(
            text = status,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.Bold
        )
    }
}
