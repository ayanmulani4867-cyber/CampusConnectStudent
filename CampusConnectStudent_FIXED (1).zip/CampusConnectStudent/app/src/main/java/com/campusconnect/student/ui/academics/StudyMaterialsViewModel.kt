package com.campusconnect.student.ui.academics

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.campusconnect.student.data.model.StudyMaterial
import com.campusconnect.student.data.repository.AcademicsExtendedRepository
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

sealed class StudyMaterialsUiState {
    object Loading : StudyMaterialsUiState()
    object Success : StudyMaterialsUiState()
    data class Error(val message: String) : StudyMaterialsUiState()
}

class StudyMaterialsViewModel(private val repository: AcademicsExtendedRepository) : ViewModel() {

    private val _uiState = mutableStateOf<StudyMaterialsUiState>(StudyMaterialsUiState.Loading)
    val uiState: State<StudyMaterialsUiState> = _uiState

    private val _studyMaterials = mutableStateOf<List<StudyMaterial>>(emptyList())
    val studyMaterials: State<List<StudyMaterial>> = _studyMaterials

    init {
        observeData()
        refresh()
    }

    private fun observeData() {
        viewModelScope.launch {
            repository.studyMaterials.collectLatest { _studyMaterials.value = it }
        }
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.value = StudyMaterialsUiState.Loading
            val result = repository.refreshStudyMaterials()
            result.onSuccess {
                _uiState.value = StudyMaterialsUiState.Success
            }.onFailure {
                _uiState.value = StudyMaterialsUiState.Error(it.message ?: "Failed to load study materials")
            }
        }
    }
}
