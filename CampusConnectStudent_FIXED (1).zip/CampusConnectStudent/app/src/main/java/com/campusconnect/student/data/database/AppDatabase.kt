package com.campusconnect.student.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.campusconnect.student.data.model.*

@Database(
    entities = [
        StudentUser::class,
        SubjectAttendance::class,
        AttendanceRecord::class,
        SemesterResult::class,
        TimetableEntry::class,
        Assignment::class,
        StudyMaterial::class,
        ExamSchedule::class,
        PaymentRecord::class,
        LeaveApplication::class,
        CertificateRecord::class,
        ComplaintRecord::class,
        CampusEvent::class,
        Notice::class,
        AppNotification::class
    ],
    version = 8,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun studentDao(): StudentDao
    abstract fun attendanceDao(): AttendanceDao
    abstract fun resultDao(): ResultDao
    abstract fun timetableDao(): TimetableDao
    abstract fun assignmentDao(): AssignmentDao
    abstract fun studyMaterialDao(): StudyMaterialDao
    abstract fun examDao(): ExamDao
    abstract fun feeDao(): FeeDao
    abstract fun leaveDao(): LeaveDao
    abstract fun certificateDao(): CertificateDao
    abstract fun complaintDao(): ComplaintDao
    abstract fun eventDao(): EventDao
    abstract fun noticeDao(): NoticeDao
    abstract fun notificationDao(): NotificationDao
}
