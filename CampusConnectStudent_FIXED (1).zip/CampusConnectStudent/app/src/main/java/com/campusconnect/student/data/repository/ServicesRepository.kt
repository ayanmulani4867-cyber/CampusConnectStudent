package com.campusconnect.student.data.repository

import com.campusconnect.student.data.api.ServicesApi
import com.campusconnect.student.data.database.FeeDao
import com.campusconnect.student.data.database.LeaveDao
import com.campusconnect.student.data.model.*
import com.campusconnect.student.data.preferences.SessionManager
import kotlinx.coroutines.flow.Flow

class ServicesRepository(
    private val api: ServicesApi,
    private val feeDao: FeeDao,
    private val leaveDao: LeaveDao,
    private val sessionManager: SessionManager
) {
    // Fees
    val paymentHistory: Flow<List<PaymentRecord>> = feeDao.getPaymentHistory()

    suspend fun refreshFees(): Result<FeeResponse> {
        return try {
            val token = sessionManager.getAuthToken() ?: return Result.failure(Exception("Not authenticated"))
            val response = api.getFees("Bearer $token")
            if (response.isSuccessful && response.body() != null) {
                val data = response.body()!!
                if (data.success) {
                    data.history?.let { feeDao.insertPaymentHistory(it) }
                    Result.success(data)
                } else {
                    Result.failure(Exception("Failed to fetch fees"))
                }
            } else {
                Result.failure(Exception("Network error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Leave
    val leaveHistory: Flow<List<LeaveApplication>> = leaveDao.getLeaveHistory()

    suspend fun refreshLeaveHistory(): Result<List<LeaveApplication>> {
        return try {
            val token = sessionManager.getAuthToken() ?: return Result.failure(Exception("Not authenticated"))
            val response = api.getLeaveHistory("Bearer $token")
            if (response.isSuccessful && response.body() != null) {
                val data = response.body()!!
                if (data.success && data.leaves != null) {
                    leaveDao.insertLeaveHistory(data.leaves)
                    Result.success(data.leaves)
                } else {
                    Result.failure(Exception("Failed to fetch leave history"))
                }
            } else {
                Result.failure(Exception("Network error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun applyLeave(request: LeaveApplyRequest): Result<String> {
        return try {
            val token = sessionManager.getAuthToken() ?: return Result.failure(Exception("Not authenticated"))
            val response = api.applyLeave("Bearer $token", request)
            if (response.isSuccessful && response.body() != null) {
                val data = response.body()!!
                if (data.success) {
                    refreshLeaveHistory()
                    Result.success(data.message ?: "Leave applied successfully")
                } else {
                    Result.failure(Exception(data.message ?: "Failed to apply for leave"))
                }
            } else {
                Result.failure(Exception("Network error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Feedback
    suspend fun submitFeedback(request: FeedbackRequest): Result<String> {
        return try {
            val token = sessionManager.getAuthToken() ?: return Result.failure(Exception("Not authenticated"))
            val response = api.submitFeedback("Bearer $token", request)
            if (response.isSuccessful && response.body() != null) {
                val data = response.body()!!
                if (data.success) {
                    Result.success(data.message ?: "Feedback submitted successfully")
                } else {
                    Result.failure(Exception(data.message ?: "Failed to submit feedback"))
                }
            } else {
                Result.failure(Exception("Network error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
