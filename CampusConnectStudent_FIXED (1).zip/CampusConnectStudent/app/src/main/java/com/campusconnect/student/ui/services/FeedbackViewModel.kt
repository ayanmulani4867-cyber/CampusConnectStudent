package com.campusconnect.student.ui.services

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.campusconnect.student.data.model.FeedbackRequest
import com.campusconnect.student.data.repository.ServicesRepository
import kotlinx.coroutines.launch

sealed class FeedbackUiState {
    object Idle : FeedbackUiState()
    object Loading : FeedbackUiState()
    object Success : FeedbackUiState()
    data class Error(val message: String) : FeedbackUiState()
}

class FeedbackViewModel(private val repository: ServicesRepository) : ViewModel() {

    private val _uiState = mutableStateOf<FeedbackUiState>(FeedbackUiState.Idle)
    val uiState: State<FeedbackUiState> = _uiState

    fun submitFeedback(type: String, rating: Int, comments: String) {
        if (comments.isBlank()) {
            _uiState.value = FeedbackUiState.Error("Please provide comments")
            return
        }

        viewModelScope.launch {
            _uiState.value = FeedbackUiState.Loading
            val result = repository.submitFeedback(FeedbackRequest(type, null, rating, comments))
            result.onSuccess {
                _uiState.value = FeedbackUiState.Success
            }.onFailure {
                _uiState.value = FeedbackUiState.Error(it.message ?: "Failed to submit feedback")
            }
        }
    }

    fun resetState() {
        _uiState.value = FeedbackUiState.Idle
    }
}
