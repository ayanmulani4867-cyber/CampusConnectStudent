package com.campusconnect.student.ui.campus

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.campusconnect.student.data.model.CertificateRecord
import com.campusconnect.student.data.repository.CampusRepository
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

sealed class CertificatesUiState {
    object Idle : CertificatesUiState()
    object Loading : CertificatesUiState()
    object Success : CertificatesUiState()
    data class Error(val message: String) : CertificatesUiState()
}

class CertificatesViewModel(private val repository: CampusRepository) : ViewModel() {

    private val _uiState = mutableStateOf<CertificatesUiState>(CertificatesUiState.Idle)
    val uiState: State<CertificatesUiState> = _uiState

    private val _certificates = mutableStateOf<List<CertificateRecord>>(emptyList())
    val certificates: State<List<CertificateRecord>> = _certificates

    init {
        observeData()
        refresh()
    }

    private fun observeData() {
        viewModelScope.launch {
            repository.certificates.collectLatest {
                _certificates.value = it
            }
        }
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.value = CertificatesUiState.Loading
            repository.refreshCertificates()
            _uiState.value = CertificatesUiState.Idle
        }
    }

    fun requestCertificate(type: String, reason: String) {
        if (type.isBlank() || reason.isBlank()) {
            _uiState.value = CertificatesUiState.Error("Please fill all fields")
            return
        }

        viewModelScope.launch {
            _uiState.value = CertificatesUiState.Loading
            val result = repository.requestCertificate(type, reason)
            result.onSuccess {
                _uiState.value = CertificatesUiState.Success
                refresh()
            }.onFailure {
                _uiState.value = CertificatesUiState.Error(it.message ?: "Failed to submit request")
            }
        }
    }

    fun resetState() {
        _uiState.value = CertificatesUiState.Idle
    }
}
