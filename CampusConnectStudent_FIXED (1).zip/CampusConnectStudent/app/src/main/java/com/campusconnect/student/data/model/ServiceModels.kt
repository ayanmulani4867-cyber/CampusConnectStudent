package com.campusconnect.student.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName

// --- FEES ---

data class FeeResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("summary") val summary: FeeSummary?,
    @SerializedName("fees") val fees: List<FeeRecord>?,
    @SerializedName("payment_history") val history: List<PaymentRecord>?
)

data class FeeSummary(
    @SerializedName("total_payable") val totalPayable: Double,
    @SerializedName("total_paid") val totalPaid: Double,
    @SerializedName("total_pending") val totalPending: Double,
    @SerializedName("is_fully_paid") val isFullyPaid: Boolean
)

data class FeeRecord(
    @SerializedName("id") val id: Int,
    @SerializedName("title") val title: String,
    @SerializedName("total_amount") val totalAmount: Double,
    @SerializedName("paid_amount") val paidAmount: Double,
    @SerializedName("pending_amount") val pendingAmount: Double,
    @SerializedName("status") val status: String,
    @SerializedName("due_date") val dueDate: String?
)

data class FeeHistoryResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("payment_history") val history: List<PaymentRecord>?
)

@Entity(tableName = "payment_history")
data class PaymentRecord(
    @PrimaryKey @SerializedName("receipt_number") val receiptNo: String,
    @SerializedName("payment_date") val date: String,
    @SerializedName("amount") val amount: Double,
    @SerializedName("payment_mode") val paymentType: String,
    @SerializedName("status") val status: String,
    @SerializedName("transaction_id") val transactionNo: String?,
    @SerializedName("notes") val notes: String?,
    @SerializedName("receipt_url") val receiptUrl: String?
)

// --- LEAVE ---

@Entity(tableName = "leave_history")
data class LeaveApplication(
    @PrimaryKey @SerializedName("id") val id: Int,
    @SerializedName("leave_type") val leaveType: String,
    @SerializedName("start_date") val startDate: String,
    @SerializedName("end_date") val endDate: String,
    @SerializedName("total_days") val totalDays: Int,
    @SerializedName("reason") val reason: String,
    @SerializedName("status") val status: String, // "Pending", "Approved", "Rejected"
    @SerializedName("applied_at") val appliedOn: String,
    @SerializedName("review_comment") val comments: String?
)

data class LeaveHistoryResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("leaves") val leaves: List<LeaveApplication>?
)

data class LeaveApplyRequest(
    @SerializedName("leave_type") val leaveType: String,
    @SerializedName("start_date") val startDate: String,
    @SerializedName("end_date") val endDate: String,
    @SerializedName("reason") val reason: String
)

data class LeaveApplyResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("message") val message: String?,
    @SerializedName("leave_id") val leaveId: Int?,
    @SerializedName("status") val status: String?
)

// --- FEEDBACK ---

data class FeedbackRequest(
    @SerializedName("feedback_type") val type: String, // "Faculty", "Course", "General"
    @SerializedName("faculty_id") val facultyId: Int?,
    @SerializedName("rating") val rating: Int,
    @SerializedName("clarity_rating") val clarityRating: Int = 5,
    @SerializedName("punctuality_rating") val punctualityRating: Int = 5,
    @SerializedName("helpfulness_rating") val helpfulnessRating: Int = 5,
    @SerializedName("comments") val comments: String,
    @SerializedName("is_anonymous") val isAnonymous: Boolean = false
)

data class FeedbackResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("message") val message: String?
)
