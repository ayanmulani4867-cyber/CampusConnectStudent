package com.campusconnect.student.data.api

import com.campusconnect.student.data.model.AssignmentResponse
import com.campusconnect.student.data.model.ExamResponse
import com.campusconnect.student.data.model.StudyMaterialResponse
import com.campusconnect.student.data.model.SubmissionResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.*

interface AcademicsExtendedApi {
    @GET("api/student/assignments")
    suspend fun getAssignments(@Header("Authorization") token: String): Response<AssignmentResponse>

    @Multipart
    @POST("api/student/assignments/{id}/submit")
    suspend fun submitAssignment(
        @Header("Authorization") token: String,
        @Path("id") assignmentId: String,
        @Part submission_file: MultipartBody.Part? = null,
        @Part("submission_text") submissionText: RequestBody? = null
    ): Response<SubmissionResponse>

    @GET("api/student/study-materials")
    suspend fun getStudyMaterials(@Header("Authorization") token: String): Response<StudyMaterialResponse>

    @GET("api/student/exams")
    suspend fun getExams(@Header("Authorization") token: String): Response<ExamResponse>
}
