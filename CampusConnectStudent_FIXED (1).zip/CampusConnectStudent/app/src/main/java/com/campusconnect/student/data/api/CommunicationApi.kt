package com.campusconnect.student.data.api

import com.campusconnect.student.data.model.*
import retrofit2.Response
import retrofit2.http.*

interface CommunicationApi {
    @GET("api/student/notices")
    suspend fun getNotices(@Header("Authorization") token: String): Response<NoticeResponse>

    @GET("api/student/notifications")
    suspend fun getNotifications(@Header("Authorization") token: String): Response<NotificationResponse>

    @POST("api/student/notifications/{id}/read")
    suspend fun markAsRead(
        @Header("Authorization") token: String,
        @Path("id") notificationId: Int
    ): Response<BaseResponse>

    @POST("api/student/notifications/read-all")
    suspend fun markAllRead(
        @Header("Authorization") token: String
    ): Response<BaseResponse>

    @POST("api/student/notifications/token")
    suspend fun syncFcmToken(
        @Header("Authorization") token: String,
        @Body request: TokenSyncRequest
    ): Response<BaseResponse>
}
