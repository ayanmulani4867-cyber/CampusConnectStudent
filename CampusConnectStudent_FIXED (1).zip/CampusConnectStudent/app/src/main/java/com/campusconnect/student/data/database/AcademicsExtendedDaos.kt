package com.campusconnect.student.data.database

import androidx.room.*
import com.campusconnect.student.data.model.Assignment
import com.campusconnect.student.data.model.ExamSchedule
import com.campusconnect.student.data.model.StudyMaterial
import kotlinx.coroutines.flow.Flow

@Dao
interface AssignmentDao {
    @Query("SELECT * FROM assignments ORDER BY deadline ASC")
    fun getAssignments(): Flow<List<Assignment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAssignments(list: List<Assignment>)

    @Query("DELETE FROM assignments")
    suspend fun clearAssignments()
}

@Dao
interface StudyMaterialDao {
    @Query("SELECT * FROM study_materials ORDER BY uploadDate DESC")
    fun getStudyMaterials(): Flow<List<StudyMaterial>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudyMaterials(list: List<StudyMaterial>)

    @Query("DELETE FROM study_materials")
    suspend fun clearStudyMaterials()
}

@Dao
interface ExamDao {
    @Query("SELECT * FROM exams ORDER BY date ASC")
    fun getExams(): Flow<List<ExamSchedule>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExams(list: List<ExamSchedule>)

    @Query("DELETE FROM exams")
    suspend fun clearExams()
}
