package com.campusconnect.student.data.api

import com.campusconnect.student.data.preferences.SessionManager
import okhttp3.Interceptor
import okhttp3.Response

class AuthInterceptor(private val sessionManager: SessionManager) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val response = chain.proceed(request)

        if (response.code == 401) {
            // Unauthorized - Token might be expired or invalid
            sessionManager.clearSession()
            // In a real app, you might want to trigger a navigation to Login
            // This can be done via an EventBus, LiveData in a singleton, or a Broadcast.
        }

        return response
    }
}
