package com.campusconnect.student.data.api

import com.campusconnect.student.data.model.*
import retrofit2.Response
import retrofit2.http.*

interface CampusApi {
    // Certificates
    @GET("api/student/certificates")
    suspend fun getCertificates(@Header("Authorization") token: String): Response<CertificateResponse>

    @POST("api/student/certificates")
    suspend fun requestCertificate(
        @Header("Authorization") token: String,
        @Body request: CertificateRequest
    ): Response<BaseResponse>

    // Complaints
    @GET("api/student/complaints")
    suspend fun getComplaints(@Header("Authorization") token: String): Response<ComplaintResponse>

    @POST("api/student/complaints")
    suspend fun createComplaint(
        @Header("Authorization") token: String,
        @Body request: ComplaintCreateRequest
    ): Response<BaseResponse>

    // Events
    @GET("api/student/events")
    suspend fun getEvents(@Header("Authorization") token: String): Response<EventResponse>

    @POST("api/student/events/register")
    suspend fun registerForEvent(
        @Header("Authorization") token: String,
        @Body request: EventRegisterRequest
    ): Response<BaseResponse>
}
