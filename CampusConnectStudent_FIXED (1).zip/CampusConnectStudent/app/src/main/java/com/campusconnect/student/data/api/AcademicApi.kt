package com.campusconnect.student.data.api

import com.campusconnect.student.data.model.AttendanceResponse
import com.campusconnect.student.data.model.ResultsResponse
import com.campusconnect.student.data.model.TimetableResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Header

interface AcademicApi {
    @GET("api/student/attendance")
    suspend fun getAttendance(@Header("Authorization") token: String): Response<AttendanceResponse>

    @GET("api/student/results")
    suspend fun getResults(@Header("Authorization") token: String): Response<ResultsResponse>

    @GET("api/student/timetable")
    suspend fun getTimetable(@Header("Authorization") token: String): Response<TimetableResponse>

    @GET("api/student/timetable/today")
    suspend fun getTimetableToday(@Header("Authorization") token: String): Response<TimetableResponse>
}
