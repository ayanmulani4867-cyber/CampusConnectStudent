package com.campusconnect.student.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String) {
    // Auth
    object Login : Screen("login")
    object ForgotPassword : Screen("forgot_password")

    // Bottom Nav
    object Home : Screen("home")
    object Academics : Screen("academics")
    object Services : Screen("services")
    object Campus : Screen("campus")
    object Profile : Screen("profile")

    // Academics
    object Attendance : Screen("attendance")
    object Results : Screen("results")
    object Timetable : Screen("timetable")
    object Assignments : Screen("assignments")
    object StudyMaterials : Screen("study_materials")
    object Exams : Screen("exams")

    // Services
    object Fees : Screen("fees")
    object Leave : Screen("leave")
    object Feedback : Screen("feedback")
    object Certificates : Screen("certificates")
    object Complaints : Screen("complaints")

    // Campus
    object Notices : Screen("notices")
    object Events : Screen("events")
    object Notifications : Screen("notifications")
}

data class BottomNavItem(
    val title: String,
    val route: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

val bottomNavItems = listOf(
    BottomNavItem(
        title = "Home",
        route = Screen.Home.route,
        selectedIcon = Icons.Filled.Home,
        unselectedIcon = Icons.Outlined.Home
    ),
    BottomNavItem(
        title = "Academics",
        route = Screen.Academics.route,
        selectedIcon = Icons.Filled.School,
        unselectedIcon = Icons.Outlined.School
    ),
    BottomNavItem(
        title = "Services",
        route = Screen.Services.route,
        selectedIcon = Icons.Filled.DesignServices,
        unselectedIcon = Icons.Outlined.DesignServices
    ),
    BottomNavItem(
        title = "Campus",
        route = Screen.Campus.route,
        selectedIcon = Icons.Filled.Notifications,
        unselectedIcon = Icons.Outlined.Notifications
    ),
    BottomNavItem(
        title = "Profile",
        route = Screen.Profile.route,
        selectedIcon = Icons.Filled.Person,
        unselectedIcon = Icons.Outlined.Person
    )
)
