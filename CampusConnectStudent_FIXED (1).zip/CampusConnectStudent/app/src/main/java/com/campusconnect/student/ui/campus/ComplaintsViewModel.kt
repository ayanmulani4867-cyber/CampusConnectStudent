package com.campusconnect.student.ui.campus

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.campusconnect.student.data.model.ComplaintRecord
import com.campusconnect.student.data.repository.CampusRepository
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

sealed class ComplaintsUiState {
    object Idle : ComplaintsUiState()
    object Loading : ComplaintsUiState()
    object Success : ComplaintsUiState()
    data class Error(val message: String) : ComplaintsUiState()
}

class ComplaintsViewModel(private val repository: CampusRepository) : ViewModel() {

    private val _uiState = mutableStateOf<ComplaintsUiState>(ComplaintsUiState.Idle)
    val uiState: State<ComplaintsUiState> = _uiState

    private val _complaints = mutableStateOf<List<ComplaintRecord>>(emptyList())
    val complaints: State<List<ComplaintRecord>> = _complaints

    init {
        observeData()
        refresh()
    }

    private fun observeData() {
        viewModelScope.launch {
            repository.complaints.collectLatest {
                _complaints.value = it
            }
        }
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.value = ComplaintsUiState.Loading
            repository.refreshComplaints()
            _uiState.value = ComplaintsUiState.Idle
        }
    }

    fun createComplaint(category: String, title: String, description: String) {
        if (category.isBlank() || title.isBlank() || description.isBlank()) {
            _uiState.value = ComplaintsUiState.Error("Please fill all fields")
            return
        }

        viewModelScope.launch {
            _uiState.value = ComplaintsUiState.Loading
            val result = repository.createComplaint(category, title, description)
            result.onSuccess {
                _uiState.value = ComplaintsUiState.Success
                refresh()
            }.onFailure {
                _uiState.value = ComplaintsUiState.Error(it.message ?: "Failed to submit complaint")
            }
        }
    }

    fun resetState() {
        _uiState.value = ComplaintsUiState.Idle
    }
}
