package com.campusconnect.student.ui.profile

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.campusconnect.student.data.model.StudentUser
import com.campusconnect.student.data.repository.StudentRepository
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import okhttp3.MultipartBody

sealed class ProfileUiState {
    object Idle : ProfileUiState()
    object Loading : ProfileUiState()
    object Success : ProfileUiState()
    data class Error(val message: String) : ProfileUiState()
}

class ProfileViewModel(private val studentRepository: StudentRepository) : ViewModel() {

    private val _uiState = mutableStateOf<ProfileUiState>(ProfileUiState.Idle)
    val uiState: State<ProfileUiState> = _uiState

    private val _studentProfile = mutableStateOf<StudentUser?>(null)
    val studentProfile: State<StudentUser?> = _studentProfile

    init {
        observeProfile()
        refreshProfile()
    }

    private fun observeProfile() {
        viewModelScope.launch {
            studentRepository.studentProfile.collectLatest { profile ->
                _studentProfile.value = profile
            }
        }
    }

    fun refreshProfile() {
        viewModelScope.launch {
            _uiState.value = ProfileUiState.Loading
            val result = studentRepository.refreshProfile()
            result.onSuccess {
                _uiState.value = ProfileUiState.Success
            }.onFailure {
                _uiState.value = ProfileUiState.Error(it.message ?: "Failed to refresh profile")
            }
        }
    }

    fun uploadPhoto(photoPart: MultipartBody.Part) {
        viewModelScope.launch {
            _uiState.value = ProfileUiState.Loading
            val result = studentRepository.uploadProfilePhoto(photoPart)
            result.onSuccess {
                _uiState.value = ProfileUiState.Success
            }.onFailure {
                _uiState.value = ProfileUiState.Error(it.message ?: "Failed to upload photo")
            }
        }
    }
}
