package com.campusconnect.student.ui.academics

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.campusconnect.student.data.model.ExamSchedule
import com.campusconnect.student.data.repository.AcademicsExtendedRepository
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

sealed class ExamsUiState {
    object Loading : ExamsUiState()
    object Success : ExamsUiState()
    data class Error(val message: String) : ExamsUiState()
}

class ExamsViewModel(private val repository: AcademicsExtendedRepository) : ViewModel() {

    private val _uiState = mutableStateOf<ExamsUiState>(ExamsUiState.Loading)
    val uiState: State<ExamsUiState> = _uiState

    private val _exams = mutableStateOf<List<ExamSchedule>>(emptyList())
    val exams: State<List<ExamSchedule>> = _exams

    init {
        observeData()
        refresh()
    }

    private fun observeData() {
        viewModelScope.launch {
            repository.exams.collectLatest { _exams.value = it }
        }
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.value = ExamsUiState.Loading
            val result = repository.refreshExams()
            result.onSuccess {
                _uiState.value = ExamsUiState.Success
            }.onFailure {
                _uiState.value = ExamsUiState.Error(it.message ?: "Failed to load exams")
            }
        }
    }
}
