package com.campusconnect.student.ui.academics

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.campusconnect.student.data.model.AttendanceRecord
import com.campusconnect.student.data.model.SubjectAttendance
import com.campusconnect.student.data.repository.AcademicRepository
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

sealed class AttendanceUiState {
    object Loading : AttendanceUiState()
    object Success : AttendanceUiState()
    data class Error(val message: String) : AttendanceUiState()
}

class AttendanceViewModel(private val repository: AcademicRepository) : ViewModel() {

    private val _uiState = mutableStateOf<AttendanceUiState>(AttendanceUiState.Loading)
    val uiState: State<AttendanceUiState> = _uiState

    private val _subjectAttendance = mutableStateOf<List<SubjectAttendance>>(emptyList())
    val subjectAttendance: State<List<SubjectAttendance>> = _subjectAttendance

    private val _attendanceHistory = mutableStateOf<List<AttendanceRecord>>(emptyList())
    val attendanceHistory: State<List<AttendanceRecord>> = _attendanceHistory

    init {
        observeData()
        refresh()
    }

    private fun observeData() {
        viewModelScope.launch {
            repository.subjectAttendance.collectLatest { _subjectAttendance.value = it }
        }
        viewModelScope.launch {
            repository.attendanceHistory.collectLatest { _attendanceHistory.value = it }
        }
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.value = AttendanceUiState.Loading
            val result = repository.refreshAttendance()
            result.onSuccess {
                _uiState.value = AttendanceUiState.Success
            }.onFailure {
                _uiState.value = AttendanceUiState.Error(it.message ?: "Failed to load attendance")
            }
        }
    }
}
