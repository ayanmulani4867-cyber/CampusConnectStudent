package com.campusconnect.student.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.campusconnect.student.data.repository.CommunicationRepository
import com.campusconnect.student.data.repository.StudentRepository

class DashboardViewModelFactory(
    private val studentRepository: StudentRepository,
    private val communicationRepository: CommunicationRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(DashboardViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return DashboardViewModel(studentRepository, communicationRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
