package com.campusconnect.student.data.repository

import com.campusconnect.student.data.api.CommunicationApi
import com.campusconnect.student.data.database.NoticeDao
import com.campusconnect.student.data.database.NotificationDao
import com.campusconnect.student.data.model.*
import com.campusconnect.student.data.preferences.SessionManager
import kotlinx.coroutines.flow.Flow

class CommunicationRepository(
    private val api: CommunicationApi,
    private val noticeDao: NoticeDao,
    private val notificationDao: NotificationDao,
    private val sessionManager: SessionManager
) {
    // Notices
    val notices: Flow<List<Notice>> = noticeDao.getNotices()

    suspend fun refreshNotices(): Result<List<Notice>> {
        return try {
            val token = sessionManager.getAuthToken() ?: return Result.failure(Exception("Not authenticated"))
            val response = api.getNotices("Bearer $token")
            if (response.isSuccessful && response.body() != null) {
                val data = response.body()!!
                if (data.success && data.notices != null) {
                    noticeDao.insertNotices(data.notices)
                    Result.success(data.notices)
                } else {
                    Result.failure(Exception("Failed to fetch notices"))
                }
            } else {
                Result.failure(Exception("Network error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Notifications
    val notifications: Flow<List<AppNotification>> = notificationDao.getNotifications()
    val unreadCount: Flow<Int> = notificationDao.getUnreadCount()

    suspend fun refreshNotifications(): Result<List<AppNotification>> {
        return try {
            val token = sessionManager.getAuthToken() ?: return Result.failure(Exception("Not authenticated"))
            val response = api.getNotifications("Bearer $token")
            if (response.isSuccessful && response.body() != null) {
                val data = response.body()!!
                if (data.success && data.notifications != null) {
                    notificationDao.insertNotifications(data.notifications)
                    Result.success(data.notifications)
                } else {
                    Result.failure(Exception("Failed to fetch notifications"))
                }
            } else {
                Result.failure(Exception("Network error: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun markAsRead(notificationId: Int? = null, markAll: Boolean = false): Result<Unit> {
        return try {
            val token = sessionManager.getAuthToken() ?: return Result.failure(Exception("Not authenticated"))
            val response = if (markAll) {
                api.markAllRead("Bearer $token")
            } else if (notificationId != null) {
                api.markAsRead("Bearer $token", notificationId)
            } else {
                return Result.failure(Exception("Notification ID required"))
            }
            
            if (response.isSuccessful && response.body()?.success == true) {
                if (markAll) notificationDao.markAllAsRead()
                else notificationId?.let { notificationDao.markAsRead(it.toString()) }
                Result.success(Unit)
            } else {
                Result.failure(Exception("Failed to mark as read"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun syncFcmToken(fcmToken: String): Result<Unit> {
        return try {
            val token = sessionManager.getAuthToken() ?: return Result.failure(Exception("Not authenticated"))
            val response = api.syncFcmToken("Bearer $token", TokenSyncRequest(fcmToken))
            if (response.isSuccessful && response.body()?.success == true) {
                Result.success(Unit)
            } else {
                Result.failure(Exception("Failed to sync FCM token"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
