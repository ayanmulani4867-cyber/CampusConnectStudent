package com.campusconnect.student.ui.services

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.campusconnect.student.data.model.LeaveApplication
import com.campusconnect.student.ui.common.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LeaveScreen(
    viewModel: LeaveViewModel,
    onBackClick: () -> Unit
) {
    val uiState by viewModel.uiState
    val history by viewModel.leaveHistory
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("History", "Apply")

    Scaffold(
        topBar = {
            CampusAppBar(
                title = "Leave Management",
                navigationIcon = Icons.Default.ArrowBack,
                onNavigationClick = onBackClick
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            TabRow(selectedTabIndex = selectedTab) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title) }
                    )
                }
            }

            when (selectedTab) {
                0 -> LeaveHistoryList(history)
                1 -> ApplyLeaveForm(viewModel)
            }
        }
    }

    if (uiState is LeaveUiState.Success) {
        AlertDialog(
            onDismissRequest = { viewModel.resetState() },
            title = { Text("Success") },
            text = { Text("Leave application submitted successfully.") },
            confirmButton = {
                TextButton(onClick = { 
                    viewModel.resetState()
                    selectedTab = 0 
                }) {
                    Text("OK")
                }
            }
        )
    }
}

@Composable
fun LeaveHistoryList(history: List<LeaveApplication>) {
    if (history.isEmpty()) {
        EmptyState(message = "No leave history found.")
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(history) { leave ->
                LeaveItem(leave)
            }
        }
    }
}

@Composable
fun LeaveItem(leave: LeaveApplication) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = leave.leaveType, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                LeaveStatusBadge(leave.status)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "${leave.startDate} to ${leave.endDate}", style = MaterialTheme.typography.bodySmall)
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(text = leave.reason, style = MaterialTheme.typography.bodyMedium, maxLines = 2)
            
            if (leave.comments != null) {
                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(thickness = 0.5.dp)
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "Comments: ${leave.comments}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
fun LeaveStatusBadge(status: String) {
    val color = when (status.lowercase()) {
        "approved" -> Color(0xFF4CAF50)
        "rejected" -> Color(0xFFF44336)
        "pending" -> Color(0xFFFF9800)
        else -> MaterialTheme.colorScheme.outline
    }
    Surface(
        color = color.copy(alpha = 0.1f),
        shape = MaterialTheme.shapes.extraSmall
    ) {
        Text(
            text = status,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun ApplyLeaveForm(viewModel: LeaveViewModel) {
    var leaveType by remember { mutableStateOf("") }
    var startDate by remember { mutableStateOf("") }
    var endDate by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    
    val uiState by viewModel.uiState

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            OutlinedTextField(
                value = leaveType,
                onValueChange = { leaveType = it },
                label = { Text("Leave Type (e.g. Sick, Academic)") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedTextField(
                value = startDate,
                onValueChange = { startDate = it },
                label = { Text("Start Date (YYYY-MM-DD)") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedTextField(
                value = endDate,
                onValueChange = { endDate = it },
                label = { Text("End Date (YYYY-MM-DD)") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedTextField(
                value = reason,
                onValueChange = { reason = it },
                label = { Text("Reason") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3
            )
        }
        item {
            if (uiState is LeaveUiState.Error) {
                Text(text = (uiState as LeaveUiState.Error).message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            Button(
                onClick = { viewModel.applyLeave(leaveType, startDate, endDate, reason) },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                enabled = uiState !is LeaveUiState.Loading
            ) {
                if (uiState is LeaveUiState.Loading) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
                } else {
                    Text("Submit Application")
                }
            }
        }
    }
}
