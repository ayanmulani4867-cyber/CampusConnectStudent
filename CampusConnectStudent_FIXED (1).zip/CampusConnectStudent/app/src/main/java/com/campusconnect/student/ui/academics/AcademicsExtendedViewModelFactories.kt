package com.campusconnect.student.ui.academics

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.campusconnect.student.data.repository.AcademicsExtendedRepository

class AssignmentsViewModelFactory(private val repository: AcademicsExtendedRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AssignmentsViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AssignmentsViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

class StudyMaterialsViewModelFactory(private val repository: AcademicsExtendedRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(StudyMaterialsViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return StudyMaterialsViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

class ExamsViewModelFactory(private val repository: AcademicsExtendedRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ExamsViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ExamsViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
