package com.campusconnect.student.data.database

import androidx.room.*
import com.campusconnect.student.data.model.StudentUser
import kotlinx.coroutines.flow.Flow

@Dao
interface StudentDao {
    @Query("SELECT * FROM student_profile LIMIT 1")
    fun getStudentProfile(): Flow<StudentUser?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudentProfile(student: StudentUser)

    @Query("DELETE FROM student_profile")
    suspend fun clearStudentProfile()
}
