package com.campusconnect.student.data.database

import androidx.room.*
import com.campusconnect.student.data.model.LeaveApplication
import com.campusconnect.student.data.model.PaymentRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface FeeDao {
    @Query("SELECT * FROM payment_history ORDER BY date DESC")
    fun getPaymentHistory(): Flow<List<PaymentRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPaymentHistory(list: List<PaymentRecord>)

    @Query("DELETE FROM payment_history")
    suspend fun clearPaymentHistory()
}

@Dao
interface LeaveDao {
    @Query("SELECT * FROM leave_history ORDER BY appliedOn DESC")
    fun getLeaveHistory(): Flow<List<LeaveApplication>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLeaveHistory(list: List<LeaveApplication>)

    @Query("DELETE FROM leave_history")
    suspend fun clearLeaveHistory()
}
