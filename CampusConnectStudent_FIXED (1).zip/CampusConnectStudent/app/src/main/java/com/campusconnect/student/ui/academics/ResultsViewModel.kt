package com.campusconnect.student.ui.academics

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.campusconnect.student.data.model.SemesterResult
import com.campusconnect.student.data.repository.AcademicRepository
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

sealed class ResultsUiState {
    object Loading : ResultsUiState()
    object Success : ResultsUiState()
    data class Error(val message: String) : ResultsUiState()
}

class ResultsViewModel(private val repository: AcademicRepository) : ViewModel() {

    private val _uiState = mutableStateOf<ResultsUiState>(ResultsUiState.Loading)
    val uiState: State<ResultsUiState> = _uiState

    private val _results = mutableStateOf<List<SemesterResult>>(emptyList())
    val results: State<List<SemesterResult>> = _results

    private val _selectedSemester = mutableStateOf<SemesterResult?>(null)
    val selectedSemester: State<SemesterResult?> = _selectedSemester

    init {
        observeData()
        refresh()
    }

    private fun observeData() {
        viewModelScope.launch {
            repository.results.collectLatest { 
                _results.value = it
                if (_selectedSemester.value == null && it.isNotEmpty()) {
                    _selectedSemester.value = it.first()
                }
            }
        }
    }

    fun onSemesterSelected(semester: SemesterResult) {
        _selectedSemester.value = semester
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.value = ResultsUiState.Loading
            val result = repository.refreshResults()
            result.onSuccess {
                _uiState.value = ResultsUiState.Success
            }.onFailure {
                _uiState.value = ResultsUiState.Error(it.message ?: "Failed to load results")
            }
        }
    }
}
