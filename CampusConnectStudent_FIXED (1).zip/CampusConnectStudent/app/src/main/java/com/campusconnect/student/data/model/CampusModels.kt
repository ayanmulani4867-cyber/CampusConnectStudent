package com.campusconnect.student.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName

// --- CERTIFICATES ---

@Entity(tableName = "certificates")
data class CertificateRecord(
    @PrimaryKey @SerializedName("id") val id: Int,
    @SerializedName("certificate_type") val type: String,
    @SerializedName("requested_at") val requestedOn: String,
    @SerializedName("status") val status: String, // "Pending", "Approved", "Rejected"
    @SerializedName("issued_date") val approvedOn: String?,
    @SerializedName("certificate_number") val certificateNumber: String?,
    @SerializedName("verification_code") val verificationCode: String?,
    @SerializedName("purpose") val purpose: String?,
    @SerializedName("download_url") val downloadUrl: String?
)

data class CertificateResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("certificates") val certificates: List<CertificateRecord>?
)

data class CertificateRequest(
    @SerializedName("certificate_type") val type: String,
    @SerializedName("purpose") val reason: String
)

// --- COMPLAINTS ---

@Entity(tableName = "complaints")
data class ComplaintRecord(
    @PrimaryKey @SerializedName("id") val id: Int,
    @SerializedName("ticket_number") val ticketId: String?,
    @SerializedName("category") val category: String,
    @SerializedName("title") val title: String,
    @SerializedName("description") val description: String,
    @SerializedName("priority") val priority: String?,
    @SerializedName("status") val status: String, // "Submitted", "Assigned", "In Progress", "Resolved", "Closed"
    @SerializedName("created_at") val createdAt: String,
    @SerializedName("resolution_notes") val resolutionComments: String?,
    @SerializedName("resolved_at") val resolvedAt: String?
)

data class ComplaintResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("complaints") val complaints: List<ComplaintRecord>?
)

data class ComplaintCreateRequest(
    @SerializedName("category") val category: String,
    @SerializedName("title") val title: String,
    @SerializedName("description") val description: String,
    @SerializedName("priority") val priority: String = "Medium",
    @SerializedName("location") val location: String? = null
)

// --- EVENTS ---

@Entity(tableName = "campus_events")
data class CampusEvent(
    @PrimaryKey @SerializedName("id") val id: Int,
    @SerializedName("title") val title: String,
    @SerializedName("description") val description: String,
    @SerializedName("event_type") val eventType: String?,
    @SerializedName("start_datetime") val startDateTime: String,
    @SerializedName("end_datetime") val endDateTime: String?,
    @SerializedName("venue") val location: String,
    @SerializedName("organizer") val organizer: String? = "Campus Administration",
    @SerializedName("is_registered") val isRegistered: Boolean,
    @SerializedName("registered_count") val registeredCount: Int?,
    @SerializedName("max_participants") val maxParticipants: Int?,
    @SerializedName("image_url") val imageUrl: String?
)

data class EventResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("events") val events: List<CampusEvent>?
)

data class EventRegisterRequest(
    @SerializedName("event_id") val eventId: Int,
    @SerializedName("action") val action: String? = "Register"
)
