package com.campusconnect.student.ui.academics

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.campusconnect.student.navigation.Screen
import com.campusconnect.student.ui.common.CampusAppBar

data class AcademicFeature(
    val title: String,
    val icon: ImageVector,
    val route: String
)

val academicFeatures = listOf(
    AcademicFeature("Attendance", Icons.Default.FactCheck, Screen.Attendance.route),
    AcademicFeature("Results", Icons.Default.Assessment, Screen.Results.route),
    AcademicFeature("Timetable", Icons.Default.CalendarMonth, Screen.Timetable.route),
    AcademicFeature("Assignments", Icons.Default.Assignment, Screen.Assignments.route),
    AcademicFeature("Study Material", Icons.Default.AutoStories, Screen.StudyMaterials.route),
    AcademicFeature("Exams", Icons.Default.EventNote, Screen.Exams.route)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AcademicsHubScreen(
    onFeatureClick: (String) -> Unit
) {
    Scaffold(
        topBar = {
            CampusAppBar(title = "Academics")
        }
    ) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(academicFeatures) { feature ->
                FeatureCard(feature, onFeatureClick)
            }
        }
    }
}

@Composable
fun FeatureCard(feature: AcademicFeature, onClick: (String) -> Unit) {
    ElevatedCard(
        onClick = { onClick(feature.route) },
        modifier = Modifier.fillMaxWidth().height(140.dp),
        shape = MaterialTheme.shapes.large
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = feature.icon,
                contentDescription = null,
                modifier = Modifier.size(40.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = feature.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
