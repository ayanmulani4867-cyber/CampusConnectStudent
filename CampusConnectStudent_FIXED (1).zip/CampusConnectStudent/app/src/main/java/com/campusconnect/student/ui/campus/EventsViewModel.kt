package com.campusconnect.student.ui.campus

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.campusconnect.student.data.model.CampusEvent
import com.campusconnect.student.data.repository.CampusRepository
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

sealed class EventsUiState {
    object Loading : EventsUiState()
    object Success : EventsUiState()
    data class Error(val message: String) : EventsUiState()
}

class EventsViewModel(private val repository: CampusRepository) : ViewModel() {

    private val _uiState = mutableStateOf<EventsUiState>(EventsUiState.Loading)
    val uiState: State<EventsUiState> = _uiState

    private val _events = mutableStateOf<List<CampusEvent>>(emptyList())
    val events: State<List<CampusEvent>> = _events

    init {
        observeData()
        refresh()
    }

    private fun observeData() {
        viewModelScope.launch {
            repository.events.collectLatest {
                _events.value = it
            }
        }
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.value = EventsUiState.Loading
            repository.refreshEvents()
            _uiState.value = EventsUiState.Success
        }
    }

    fun toggleRegistration(event: CampusEvent) {
        viewModelScope.launch {
            _uiState.value = EventsUiState.Loading
            val result = repository.registerForEvent(event.id, !event.isRegistered)
            result.onSuccess {
                _uiState.value = EventsUiState.Success
            }.onFailure {
                _uiState.value = EventsUiState.Error(it.message ?: "Failed to update registration")
            }
        }
    }
}
