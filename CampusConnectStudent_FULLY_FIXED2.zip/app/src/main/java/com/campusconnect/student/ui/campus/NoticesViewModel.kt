package com.campusconnect.student.ui.campus

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.campusconnect.student.data.model.Notice
import com.campusconnect.student.data.repository.CommunicationRepository
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

sealed class NoticesUiState {
    object Loading : NoticesUiState()
    object Success : NoticesUiState()
    data class Error(val message: String) : NoticesUiState()
}

class NoticesViewModel(private val repository: CommunicationRepository) : ViewModel() {

    private val _uiState = mutableStateOf<NoticesUiState>(NoticesUiState.Loading)
    val uiState: State<NoticesUiState> = _uiState

    private val _notices = mutableStateOf<List<Notice>>(emptyList())
    val notices: State<List<Notice>> = _notices

    private val _selectedCategory = mutableStateOf("All")
    val selectedCategory: State<String> = _selectedCategory

    val categories = listOf("All", "Low", "Medium", "High", "Important", "General")

    init {
        observeData()
        refresh()
    }

    private fun observeData() {
        viewModelScope.launch {
            repository.notices.collectLatest {
                _notices.value = it
            }
        }
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.value = NoticesUiState.Loading
            val result = repository.refreshNotices()
            result.onSuccess {
                _uiState.value = NoticesUiState.Success
            }.onFailure {
                _uiState.value = NoticesUiState.Error(it.message ?: "Failed to load notices")
            }
        }
    }

    fun onCategorySelected(category: String) {
        _selectedCategory.value = category
    }
}
